# Build the real Sendora test APK

This repository now includes `.github/workflows/build-apk.yml`.

1. Push the whole project to GitHub.
2. Open **Actions** in the repository.
3. Select **Build Sendora Test APK**.
4. Click **Run workflow** if it did not start automatically.
5. Wait for the green **Build Sendora Test APK** run to finish.
6. Open the completed run and find **Artifacts**.
7. Download **sendora-test-apk**.
8. Extract the artifact and install `app-debug.apk` on both Android phones.

This is a debug/test APK, not a production-signed release.

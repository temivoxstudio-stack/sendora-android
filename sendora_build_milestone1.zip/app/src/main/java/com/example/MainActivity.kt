package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.database.AppDatabase
import com.example.data.model.FileCategory
import com.example.data.model.SelectedFile
import com.example.data.repository.SettingsRepository
import com.example.data.repository.TransferHistoryRepository
import com.example.content.LocalContentRepository
import com.example.network.discovery.DeviceDiscoveryManager
import com.example.network.transfer.TransferManager
import com.example.ui.screens.DeviceConnectScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ReceiveScreen
import com.example.ui.screens.LocalContentScreen
import com.example.ui.screens.SendScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TransferCompletedScreen
import com.example.ui.screens.TransferScreen
import com.example.ui.theme.SendoraTheme

class MainActivity : ComponentActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var historyRepository: TransferHistoryRepository
    private lateinit var discoveryManager: DeviceDiscoveryManager
    private lateinit var transferManager: TransferManager
    private lateinit var localContentRepository: LocalContentRepository

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        settingsRepository = SettingsRepository(this)
        val database = AppDatabase.getInstance(this)
        historyRepository = TransferHistoryRepository(database.transferDao())

        val scope = lifecycleScope

        discoveryManager = DeviceDiscoveryManager(this, scope)
        transferManager = TransferManager(this, scope)
        localContentRepository = LocalContentRepository(this)

        requestRequiredPermissions()

        setContent {
            val settings by settingsRepository.settings.collectAsStateWithLifecycle()

            val darkTheme = when (settings.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            SendoraTheme(darkTheme = darkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SendoraAppNavigation(
                        settingsRepository = settingsRepository,
                        historyRepository = historyRepository,
                        discoveryManager = discoveryManager,
                        transferManager = transferManager,
                        localContentRepository = localContentRepository
                    )
                }
            }
        }
    }

    private fun requestRequiredPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_IMAGES)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }
}

@Composable
fun SendoraAppNavigation(
    settingsRepository: SettingsRepository,
    historyRepository: TransferHistoryRepository,
    discoveryManager: DeviceDiscoveryManager,
    transferManager: TransferManager,
    localContentRepository: LocalContentRepository
) {
    val navController = rememberNavController()
    var selectedFilesForSend by remember { mutableStateOf<List<SelectedFile>>(emptyList()) }
    var selectedCategoryForSend by remember { mutableStateOf<FileCategory?>(null) }

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            HomeScreen(
                settingsRepository = settingsRepository,
                historyRepository = historyRepository,
                onNavigateToSend = { category ->
                    selectedCategoryForSend = category
                    navController.navigate("send")
                },
                onNavigateToReceive = { navController.navigate("receive") },
                onNavigateToConnect = { navController.navigate("connect") },
                onNavigateToHistory = { navController.navigate("history") },
                onNavigateToSettings = { navController.navigate("settings") },
                onNavigateToContent = { category -> navController.navigate("content/${category.name}") },
                transferManager = transferManager
            )
        }

        composable("content/{category}") { backStackEntry ->
            val categoryName = backStackEntry.arguments?.getString("category")
            val category = runCatching { FileCategory.valueOf(categoryName ?: FileCategory.OTHER.name) }.getOrDefault(FileCategory.OTHER)
            LocalContentScreen(
                repository = localContentRepository,
                category = category,
                onBack = { navController.popBackStack() }
            )
        }

        composable("send") {
            SendScreen(
                initialCategory = selectedCategoryForSend,
                onBack = { navController.popBackStack() },
                onContinueToConnect = { files ->
                    selectedFilesForSend = files
                    navController.navigate("connect")
                }
            )
        }

        composable("receive") {
            ReceiveScreen(
                settingsRepository = settingsRepository,
                discoveryManager = discoveryManager,
                transferManager = transferManager,
                onBack = { navController.popBackStack() },
                onTransferAccepted = { navController.navigate("transfer") }
            )
        }

        composable("connect") {
            DeviceConnectScreen(
                selectedFiles = selectedFilesForSend,
                settingsRepository = settingsRepository,
                discoveryManager = discoveryManager,
                transferManager = transferManager,
                onBack = { navController.popBackStack() },
                onTransferStarted = { navController.navigate("transfer") }
            )
        }

        composable("transfer") {
            TransferScreen(
                transferManager = transferManager,
                onTransferComplete = { navController.navigate("transfer_completed") },
                onCancel = { navController.popBackStack("home", false) }
            )
        }

        composable("transfer_completed") {
            TransferCompletedScreen(
                transferManager = transferManager,
                onTransferMore = { navController.navigate("send") },
                onBackHome = { navController.popBackStack("home", false) }
            )
        }

        composable("history") {
            HistoryScreen(
                historyRepository = historyRepository,
                onBack = { navController.popBackStack() }
            )
        }

        composable("settings") {
            SettingsScreen(
                settingsRepository = settingsRepository,
                onBack = { navController.popBackStack() }
            )
        }
    }
}

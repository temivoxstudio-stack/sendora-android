package com.example.content

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.MediaStore
import com.example.data.model.FileCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Scans content that belongs to the phone currently running Sendora. */
class LocalContentRepository(private val context: Context) {

    data class LocalContentItem(
        val id: String,
        val name: String,
        val uri: Uri,
        val size: Long,
        val mimeType: String,
        val category: FileCategory,
        val durationMs: Long = 0L,
        val artist: String? = null,
        val appPackage: String? = null,
        val appIcon: Bitmap? = null
    )

    suspend fun scan(category: FileCategory): List<LocalContentItem> = withContext(Dispatchers.IO) {
        when (category) {
            FileCategory.APKS -> scanApps()
            FileCategory.PHOTOS -> scanMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, FileCategory.PHOTOS)
            FileCategory.VIDEOS -> scanMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, FileCategory.VIDEOS)
            FileCategory.MUSIC -> scanMusic()
            FileCategory.DOCUMENTS, FileCategory.ZIPS, FileCategory.OTHER -> scanFiles()
        }
    }

    private fun scanApps(): List<LocalContentItem> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .mapNotNull { info ->
                val appInfo = info.activityInfo.applicationInfo ?: return@mapNotNull null
                val source = appInfo.sourceDir ?: return@mapNotNull null
                val apk = File(source)
                LocalContentItem(
                    id = "app:${appInfo.packageName}",
                    name = appInfo.loadLabel(pm).toString(),
                    uri = Uri.fromFile(apk),
                    size = apk.length(),
                    mimeType = "application/vnd.android.package-archive",
                    category = FileCategory.APKS,
                    appPackage = appInfo.packageName,
                    appIcon = drawableToBitmap(appInfo.loadIcon(pm))
                )
            }
            .sortedBy { it.name.lowercase() }
    }

    private fun scanMedia(uri: Uri, category: FileCategory): List<LocalContentItem> {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DURATION
        )
        return runCatching {
            context.contentResolver.query(uri, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val durationCol = cursor.getColumnIndex(MediaStore.MediaColumns.DURATION)
                buildList {
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        add(LocalContentItem(
                            id = "$category:$id",
                            name = cursor.getString(nameCol) ?: "Unnamed",
                            uri = Uri.withAppendedPath(uri, id.toString()),
                            size = cursor.getLong(sizeCol).coerceAtLeast(0),
                            mimeType = cursor.getString(mimeCol) ?: "application/octet-stream",
                            category = category,
                            durationMs = if (durationCol >= 0) cursor.getLong(durationCol) else 0L
                        ))
                    }
                }
            } ?: emptyList()
        }.getOrElse { emptyList() }
    }

    private fun scanMusic(): List<LocalContentItem> {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ARTIST
        )
        return runCatching {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0",
                null,
                "${MediaStore.Audio.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                buildList {
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        add(LocalContentItem(
                            id = "music:$id",
                            name = cursor.getString(nameCol) ?: "Unnamed",
                            uri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString()),
                            size = cursor.getLong(sizeCol).coerceAtLeast(0),
                            mimeType = cursor.getString(mimeCol) ?: "audio/*",
                            category = FileCategory.MUSIC,
                            durationMs = if (durationCol >= 0) cursor.getLong(durationCol) else 0L,
                            artist = if (artistCol >= 0) cursor.getString(artistCol) else null
                        ))
                    }
                }
            } ?: emptyList()
        }.getOrElse { emptyList() }
    }

    private fun scanFiles(): List<LocalContentItem> {
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.MEDIA_TYPE
        )
        return runCatching {
            context.contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                projection,
                "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_NONE}",
                null,
                "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)
                buildList {
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(nameCol) ?: continue
                        val mime = cursor.getString(mimeCol) ?: "application/octet-stream"
                        val category = categoryFor(name, mime)
                        if (category == FileCategory.DOCUMENTS || category == FileCategory.ZIPS || category == FileCategory.OTHER) {
                            val id = cursor.getLong(idCol)
                            add(LocalContentItem(
                                id = "file:$id",
                                name = name,
                                uri = Uri.withAppendedPath(MediaStore.Files.getContentUri("external"), id.toString()),
                                size = cursor.getLong(sizeCol).coerceAtLeast(0),
                                mimeType = mime,
                                category = category
                            ))
                        }
                    }
                }
            } ?: emptyList()
        }.getOrElse { emptyList() }
    }

    private fun categoryFor(name: String, mime: String): FileCategory {
        val lower = name.lowercase()
        return when {
            mime.contains("pdf") || mime.contains("document") || mime.startsWith("text/") || lower.endsWith(".doc") || lower.endsWith(".docx") || lower.endsWith(".txt") || lower.endsWith(".epub") -> FileCategory.DOCUMENTS
            mime.contains("zip") || mime.contains("rar") || mime.contains("7z") || lower.endsWith(".zip") || lower.endsWith(".rar") || lower.endsWith(".7z") -> FileCategory.ZIPS
            else -> FileCategory.OTHER
        }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        val width = 96
        val height = 96
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, width, height)
        drawable.draw(canvas)
        return bitmap
    }
}

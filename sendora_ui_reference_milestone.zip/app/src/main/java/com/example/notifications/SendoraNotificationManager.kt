package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity

class SendoraNotificationManager(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "sendora_transfers_channel"
        const val COMPLETE_NOTIFICATION_ID = 1002
    }

    init { createNotificationChannel() }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sendora File Transfers",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications when individual Sendora files finish transferring"
            }
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    /** Deliberately no progress notification: the live queue is shown inside the app. */
    fun showTransferProgress(fileName: String, progressPercent: Int, speedText: String) = Unit

    fun showFileCompleted(fileName: String, sizeBytes: Long, received: Boolean) {
        if (!hasNotificationPermission()) return
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (received) "File received" else "File sent"
        val icon = if (received) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_sys_upload_done
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(icon)
            .setContentTitle("✓ $title")
            .setContentText("$fileName • ${formatSize(sizeBytes)}")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
        try {
            NotificationManagerCompat.from(context).notify(
                (COMPLETE_NOTIFICATION_ID + (System.currentTimeMillis() % 1000)).toInt(),
                builder.build()
            )
        } catch (_: Exception) {}
    }

    fun showTransferCompleted(fileName: String, totalFiles: Int, totalSizeText: String) = Unit
    fun cancelProgress() = Unit

    private fun hasNotificationPermission(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    } else true

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1024 * 1024 * 1024 -> "%.2f GB".format(bytes / (1024f * 1024f * 1024f))
        bytes >= 1024 * 1024 -> "%.1f MB".format(bytes / (1024f * 1024f))
        bytes >= 1024 -> "%.0f KB".format(bytes / 1024f)
        else -> "$bytes B"
    }
}

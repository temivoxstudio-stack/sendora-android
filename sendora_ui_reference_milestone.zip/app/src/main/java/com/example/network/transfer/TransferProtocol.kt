package com.example.network.transfer

import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException

/**
 * Sendora's framed local peer protocol.
 *
 * Control frames are length-prefixed UTF-8 JSON. File bytes follow FILE_BEGIN
 * and are read using the exact declared byte count. A single TCP session may
 * carry many transfer requests in either direction without reconnecting.
 */
object TransferProtocol {
    const val PROTOCOL_VERSION = "2.0"

    const val COMMAND_HANDSHAKE = "HANDSHAKE"
    const val COMMAND_HANDSHAKE_ACK = "HANDSHAKE_ACK"
    const val COMMAND_SESSION_READY = "SESSION_READY"
    const val COMMAND_PROPOSE_FILES = "PROPOSE_FILES"
    const val COMMAND_ACCEPT_FILES = "ACCEPT_FILES"
    const val COMMAND_REJECT_FILES = "REJECT_FILES"
    const val COMMAND_START_FILE = "START_FILE"
    const val COMMAND_END_FILE = "END_FILE"
    const val COMMAND_PAUSE = "PAUSE"
    const val COMMAND_RESUME = "RESUME"
    const val COMMAND_CANCEL = "CANCEL"
    const val COMMAND_PING = "PING"
    const val COMMAND_PONG = "PONG"
    const val COMMAND_DISCONNECT = "DISCONNECT"

    private const val MAX_CONTROL_MESSAGE_BYTES = 1024 * 1024

    data class FileMeta(
        val index: Int,
        val name: String,
        val size: Long,
        val mimeType: String,
        val categoryName: String
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("index", index)
            put("name", name)
            put("size", size)
            put("mimeType", mimeType)
            put("category", categoryName)
        }

        companion object {
            fun fromJson(json: JSONObject): FileMeta = FileMeta(
                index = json.getInt("index"),
                name = json.getString("name"),
                size = json.getLong("size"),
                mimeType = json.optString("mimeType", "application/octet-stream"),
                categoryName = json.optString("category", "OTHER")
            )
        }
    }

    fun buildHandshake(deviceName: String, authToken: String = ""): String = JSONObject().apply {
        put("cmd", COMMAND_HANDSHAKE)
        put("deviceName", deviceName)
        put("authToken", authToken)
        put("version", PROTOCOL_VERSION)
    }.toString()

    fun buildHandshakeAck(deviceName: String): String = JSONObject().apply {
        put("cmd", COMMAND_HANDSHAKE_ACK)
        put("deviceName", deviceName)
        put("version", PROTOCOL_VERSION)
    }.toString()

    fun buildSessionReady(deviceName: String): String = JSONObject().apply {
        put("cmd", COMMAND_SESSION_READY)
        put("deviceName", deviceName)
        put("version", PROTOCOL_VERSION)
    }.toString()

    fun buildProposeFiles(deviceName: String, files: List<FileMeta>): String {
        val array = JSONArray()
        files.forEach { array.put(it.toJson()) }
        return JSONObject().apply {
            put("cmd", COMMAND_PROPOSE_FILES)
            put("deviceName", deviceName)
            put("files", array)
            put("version", PROTOCOL_VERSION)
        }.toString()
    }

    fun buildResponse(cmd: String, message: String = ""): String = JSONObject().apply {
        put("cmd", cmd)
        put("msg", message)
    }.toString()

    @Throws(IOException::class)
    fun writeFrame(output: DataOutputStream, message: String) {
        val bytes = message.toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_CONTROL_MESSAGE_BYTES) { "Control message is too large" }
        output.writeInt(bytes.size)
        output.write(bytes)
        output.flush()
    }

    @Throws(IOException::class)
    fun readFrame(input: DataInputStream): String {
        val length = try {
            input.readInt()
        } catch (e: EOFException) {
            throw e
        }
        if (length < 0 || length > MAX_CONTROL_MESSAGE_BYTES) {
            throw IOException("Invalid control message length: $length")
        }
        val bytes = ByteArray(length)
        input.readFully(bytes)
        return String(bytes, Charsets.UTF_8)
    }
}

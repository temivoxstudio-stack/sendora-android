package com.example.network.transfer

import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.example.data.database.AppDatabase
import com.example.data.database.TransferEntity
import com.example.data.model.FileCategory
import com.example.data.model.SelectedFile
import com.example.data.model.TransferDirection
import com.example.data.model.TransferStatus
import com.example.notifications.SendoraNotificationManager
import com.example.storage.FileManager
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.Locale

/**
 * Persistent peer session + transfer queue manager.
 *
 * A TCP socket is established once and remains alive after a transfer batch.
 * The same socket can subsequently carry a transfer initiated by either phone.
 * One reader coroutine owns the socket input stream; requests waiting for a
 * response are completed by that reader, avoiding concurrent DataInputStream
 * reads when a device changes transfer direction.
 */
class TransferManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val tag = "SendoraTransferManager"
    private val fileManager = FileManager(context)
    private val notificationManager = SendoraNotificationManager(context)
    private val db = AppDatabase.getInstance(context)
    private val socketWriteMutex = Mutex()

    data class TransferItemState(
        val index: Int,
        val name: String,
        val size: Long,
        val transferred: Long = 0,
        val status: TransferItemStatus = TransferItemStatus.WAITING,
        val error: String? = null
    ) {
        val progressPercent: Int
            get() = if (size <= 0) 100 else ((transferred * 100L) / size).toInt().coerceIn(0, 100)
    }

    enum class TransferItemStatus { WAITING, IN_PROGRESS, COMPLETED, FAILED, CANCELLED }

    data class IncomingProposal(
        val senderName: String,
        val files: List<TransferProtocol.FileMeta>,
        val totalSize: Long,
        val socket: Socket,
        internal val decision: CompletableDeferred<Boolean> = CompletableDeferred()
    )

    data class ActiveTransferState(
        val isReceiver: Boolean = false,
        val status: TransferStatus = TransferStatus.PENDING,
        val remoteDeviceName: String = "",
        val remoteIpAddress: String = "",
        val filesCount: Int = 0,
        val currentFileIndex: Int = 0,
        val currentFileName: String = "",
        val currentFileSize: Long = 0,
        val currentBytesTransferred: Long = 0,
        val totalSize: Long = 0,
        val totalBytesTransferred: Long = 0,
        val speedBps: Long = 0,
        val speedText: String = "0 KB/s",
        val progressPercent: Int = 0,
        val remainingSeconds: Long = 0,
        val errorMessage: String? = null,
        val incomingProposal: IncomingProposal? = null,
        val queue: List<TransferItemState> = emptyList()
    )

    private class PeerSession(
        val socket: Socket,
        val remoteIp: String,
        var remoteName: String
    ) {
        val input = DataInputStream(socket.getInputStream())
        val output = DataOutputStream(socket.getOutputStream())
        val readerJob: Job? = null
        var running = true
        var pendingResponse: CompletableDeferred<String>? = null
        var pendingProposal: IncomingProposal? = null
        val transferMutex = Mutex()
    }

    private val _transferState = MutableStateFlow(ActiveTransferState())
    val transferState: StateFlow<ActiveTransferState> = _transferState.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var session: PeerSession? = null
    private var sessionReaderJob: Job? = null
    private var currentTransferJob: Job? = null

    @Volatile private var isPaused = false
    @Volatile private var isCancelled = false

    fun startServer(deviceName: String, port: Int = 8888) {
        stopServer()
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket(port)
                Log.d(tag, "Persistent server started on port $port")
                while (isActive) {
                    val accepted = serverSocket?.accept() ?: break
                    if (session?.socket?.isConnected == true && session?.socket?.isClosed == false) {
                        // One active peer session at a time. Reject extra connections cleanly.
                        accepted.close()
                        continue
                    }
                    attachSession(accepted, deviceName, accepted.inetAddress.hostAddress ?: "")
                }
            } catch (e: Exception) {
                if (isActive) Log.e(tag, "Server socket error: ${e.message}")
            }
        }
    }

    fun stopServer() {
        serverJob?.cancel()
        serverJob = null
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
    }

    fun isConnected(): Boolean = session?.socket?.isConnected == true && session?.socket?.isClosed == false

    fun connectedPeerName(): String = session?.remoteName.orEmpty()
    fun connectedPeerIp(): String = session?.remoteIp.orEmpty()
    fun connectedPeerPort(): Int = session?.socket?.port ?: 8888

    /** Explicit user disconnect. This ends the persistent session. */
    fun disconnect() {
        scope.launch(Dispatchers.IO) {
            val active = session
            try {
                if (active != null && !active.socket.isClosed) {
                    socketWriteMutex.withLock {
                        TransferProtocol.writeFrame(active.output, TransferProtocol.buildResponse(TransferProtocol.COMMAND_DISCONNECT))
                    }
                }
            } catch (_: Exception) {
            } finally {
                closeSession()
                _transferState.value = ActiveTransferState(status = TransferStatus.PENDING)
            }
        }
    }

    private fun attachSession(socket: Socket, localName: String, remoteIp: String) {
        try { socket.tcpNoDelay = true } catch (_: Exception) {}
        val newSession = PeerSession(socket, remoteIp, "Sendora Device")
        session = newSession
        sessionReaderJob?.cancel()
        sessionReaderJob = scope.launch(Dispatchers.IO) {
            runSessionReader(newSession, localName)
        }
    }

    private suspend fun runSessionReader(peer: PeerSession, localName: String) {
        try {
            // The peer that initiated the TCP connection sends the handshake.
            while (peer.running && !peer.socket.isClosed) {
                val frame = TransferProtocol.readFrame(peer.input)
                val json = JSONObject(frame)
                when (val cmd = json.optString("cmd")) {
                    TransferProtocol.COMMAND_HANDSHAKE -> {
                        peer.remoteName = json.optString("deviceName", "Sendora Device")
                        socketWriteMutex.withLock {
                            TransferProtocol.writeFrame(peer.output, TransferProtocol.buildHandshakeAck(localName))
                            TransferProtocol.writeFrame(peer.output, TransferProtocol.buildSessionReady(localName))
                        }
                    }
                    TransferProtocol.COMMAND_HANDSHAKE_ACK,
                    TransferProtocol.COMMAND_SESSION_READY,
                    TransferProtocol.COMMAND_ACCEPT_FILES,
                    TransferProtocol.COMMAND_REJECT_FILES,
                    TransferProtocol.COMMAND_PONG -> {
                        peer.pendingResponse?.complete(frame)
                        peer.pendingResponse = null
                    }
                    TransferProtocol.COMMAND_PING -> {
                        socketWriteMutex.withLock {
                            TransferProtocol.writeFrame(peer.output, TransferProtocol.buildResponse(TransferProtocol.COMMAND_PONG))
                        }
                    }
                    TransferProtocol.COMMAND_PROPOSE_FILES -> {
                        handleProposalFrame(peer, json)
                    }
                    TransferProtocol.COMMAND_DISCONNECT -> {
                        peer.running = false
                        break
                    }
                    else -> Log.w(tag, "Ignoring unknown session command: $cmd")
                }
            }
        } catch (e: Exception) {
            if (peer.running) Log.w(tag, "Persistent session ended: ${e.message}")
        } finally {
            if (session === peer) {
                closeSession(peer)
                if (_transferState.value.status != TransferStatus.TRANSFERRING) {
                    _transferState.value = _transferState.value.copy(
                        status = TransferStatus.FAILED,
                        errorMessage = "Connection lost"
                    )
                }
            }
        }
    }

    private suspend fun handleProposalFrame(peer: PeerSession, json: JSONObject) {
        val senderName = json.optString("deviceName", "Sendora Device")
        peer.remoteName = senderName
        val filesJson = json.optJSONArray("files") ?: throw IllegalArgumentException("Missing files")
        val files = ArrayList<TransferProtocol.FileMeta>(filesJson.length())
        var totalSize = 0L
        for (i in 0 until filesJson.length()) {
            val meta = TransferProtocol.FileMeta.fromJson(filesJson.getJSONObject(i))
            require(meta.size >= 0) { "Invalid file size" }
            files += meta
            totalSize = Math.addExact(totalSize, meta.size)
        }

        val proposal = IncomingProposal(senderName, files, totalSize, peer.socket)
        peer.pendingProposal = proposal
        _transferState.value = ActiveTransferState(
            isReceiver = true,
            status = TransferStatus.CONNECTING,
            remoteDeviceName = senderName,
            remoteIpAddress = peer.remoteIp,
            filesCount = files.size,
            totalSize = totalSize,
            incomingProposal = proposal,
            queue = files.map { TransferItemState(it.index, it.name, it.size) }
        )

        peer.transferMutex.withLock {
            val accepted = try { proposal.decision.await() } catch (_: Exception) { false }
            peer.pendingProposal = null
            if (!accepted) {
                socketWriteMutex.withLock {
                    TransferProtocol.writeFrame(peer.output, TransferProtocol.buildResponse(TransferProtocol.COMMAND_REJECT_FILES, "Rejected by user"))
                }
                return@withLock
            }

            socketWriteMutex.withLock {
                TransferProtocol.writeFrame(peer.output, TransferProtocol.buildResponse(TransferProtocol.COMMAND_ACCEPT_FILES, "Accepted"))
            }
            executeReceiveFiles(peer, files, senderName)
        }
    }

    fun acceptIncomingTransfer(proposal: IncomingProposal) {
        if (proposal.decision.isCompleted) return
        proposal.decision.complete(true)
        _transferState.value = _transferState.value.copy(
            incomingProposal = null,
            status = TransferStatus.TRANSFERRING,
            isReceiver = true
        )
    }

    fun rejectIncomingTransfer(proposal: IncomingProposal) {
        if (!proposal.decision.isCompleted) proposal.decision.complete(false)
        _transferState.value = _transferState.value.copy(incomingProposal = null)
    }

    fun sendFilesToDevice(
        targetIp: String,
        targetPort: Int,
        files: List<SelectedFile>,
        myDeviceName: String
    ) {
        if (files.isEmpty()) return
        isPaused = false
        isCancelled = false

        val metas = files.mapIndexed { idx, sf ->
            TransferProtocol.FileMeta(idx, sf.name, sf.size, sf.mimeType, sf.category.name)
        }
        val queue = files.mapIndexed { idx, file -> TransferItemState(idx, file.name, file.size) }
        val totalSize = files.sumOf { it.size }

        _transferState.value = ActiveTransferState(
            isReceiver = false,
            status = TransferStatus.CONNECTING,
            remoteDeviceName = session?.remoteName ?: "Target Device",
            remoteIpAddress = session?.remoteIp ?: targetIp,
            filesCount = files.size,
            totalSize = totalSize,
            queue = queue
        )

        currentTransferJob?.cancel()
        currentTransferJob = scope.launch(Dispatchers.IO) {
            try {
                val peer = ensureConnected(targetIp, targetPort, myDeviceName)
                peer.transferMutex.withLock {
                    val proposal = TransferProtocol.buildProposeFiles(myDeviceName, metas)
                    val responseWaiter = CompletableDeferred<String>()
                    peer.pendingResponse = responseWaiter
                    socketWriteMutex.withLock { TransferProtocol.writeFrame(peer.output, proposal) }
                    val response = responseWaiter.await()
                    val responseJson = JSONObject(response)
                    if (responseJson.optString("cmd") == TransferProtocol.COMMAND_REJECT_FILES) {
                        _transferState.value = _transferState.value.copy(
                            status = TransferStatus.REJECTED,
                            errorMessage = responseJson.optString("msg", "Receiver rejected the transfer")
                        )
                        return@withLock
                    }
                    if (responseJson.optString("cmd") != TransferProtocol.COMMAND_ACCEPT_FILES) {
                        throw IllegalStateException("Unexpected receiver response")
                    }
                    executeSendFiles(peer, files, metas, myDeviceName)
                }
            } catch (e: Exception) {
                Log.e(tag, "Send files error", e)
                _transferState.value = _transferState.value.copy(
                    status = if (e is SocketException) TransferStatus.FAILED else TransferStatus.FAILED,
                    errorMessage = e.message ?: "Transfer failed"
                )
            } finally {
                // IMPORTANT: do not close the socket here. The session is persistent.
                notificationManager.cancelProgress()
            }
        }
    }

    private suspend fun ensureConnected(targetIp: String, targetPort: Int, localName: String): PeerSession {
        val existing = session
        if (existing != null && existing.socket.isConnected && !existing.socket.isClosed) {
            return existing
        }

        _transferState.value = _transferState.value.copy(status = TransferStatus.CONNECTING)
        val socket = Socket(targetIp, targetPort)
        try { socket.tcpNoDelay = true } catch (_: Exception) {}
        val peer = PeerSession(socket, targetIp, "Target Device")
        session = peer
        sessionReaderJob?.cancel()
        sessionReaderJob = scope.launch(Dispatchers.IO) { runSessionReader(peer, localName) }

        val responseWaiter = CompletableDeferred<String>()
        peer.pendingResponse = responseWaiter
        socketWriteMutex.withLock {
            TransferProtocol.writeFrame(peer.output, TransferProtocol.buildHandshake(localName))
        }
        // The reader accepts both ACK and READY; wait for the first handshake response.
        withContext(Dispatchers.IO) { responseWaiter.await() }
        _transferState.value = _transferState.value.copy(
            status = TransferStatus.CONNECTING,
            remoteDeviceName = peer.remoteName,
            remoteIpAddress = peer.remoteIp
        )
        return peer
    }

    private suspend fun executeSendFiles(
        peer: PeerSession,
        files: List<SelectedFile>,
        metas: List<TransferProtocol.FileMeta>,
        myDeviceName: String
    ) {
        _transferState.value = _transferState.value.copy(
            status = TransferStatus.TRANSFERRING,
            incomingProposal = null
        )
        val startTime = SystemClock.elapsedRealtime()
        var overallTransferred = 0L
        val totalSize = files.sumOf { it.size }

        for (index in files.indices) {
            if (isCancelled) break
            val file = files[index]
            val meta = metas[index]
            updateQueueItem(index) { it.copy(status = TransferItemStatus.IN_PROGRESS, transferred = 0) }
            _transferState.value = _transferState.value.copy(
                currentFileIndex = index + 1,
                currentFileName = file.name,
                currentFileSize = file.size,
                currentBytesTransferred = 0
            )

            socketWriteMutex.withLock { TransferProtocol.writeFrame(peer.output, meta.toJson().toString()) }
            val input = fileManager.openInputStream(file.uri)
                ?: throw IllegalStateException("Cannot open selected file: ${file.name}")

            val buffer = ByteArray(256 * 1024)
            var fileTransferred = 0L
            var lastTick = SystemClock.elapsedRealtime()
            var bytesSinceTick = 0L
            input.use { stream ->
                while (true) {
                    if (isCancelled) break
                    while (isPaused) {
                        delay(200)
                        if (isCancelled) break
                    }
                    val read = stream.read(buffer)
                    if (read < 0) break
                    socketWriteMutex.withLock { peer.output.write(buffer, 0, read) }
                    fileTransferred += read
                    overallTransferred += read
                    bytesSinceTick += read
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastTick >= 500) {
                        val bps = bytesSinceTick * 1000 / (now - lastTick)
                        publishProgress(index, fileTransferred, overallTransferred, totalSize, bps)
                        lastTick = now
                        bytesSinceTick = 0
                    }
                }
            }

            if (isCancelled) {
                updateQueueItem(index) { it.copy(status = TransferItemStatus.CANCELLED, transferred = fileTransferred) }
                break
            }
            if (fileTransferred != file.size) {
                updateQueueItem(index) { it.copy(status = TransferItemStatus.FAILED, transferred = fileTransferred, error = "Incomplete transfer") }
                throw IOException("Incomplete send: ${file.name} ($fileTransferred/${file.size})")
            }

            socketWriteMutex.withLock {
                TransferProtocol.writeFrame(peer.output, JSONObject().apply {
                    put("cmd", TransferProtocol.COMMAND_END_FILE)
                    put("index", meta.index)
                }.toString())
            }
            updateQueueItem(index) { it.copy(status = TransferItemStatus.COMPLETED, transferred = file.size) }
            saveHistoryRecord(file.name, file.size, file.mimeType, file.category, file.uri.toString(), peer.remoteName, TransferStatus.COMPLETED, TransferDirection.SENT, SystemClock.elapsedRealtime() - startTime)
            notificationManager.showFileCompleted(file.name, file.size, received = false)
        }

        if (isCancelled) {
            _transferState.value = _transferState.value.copy(status = TransferStatus.CANCELLED)
        } else {
            _transferState.value = _transferState.value.copy(
                status = TransferStatus.COMPLETED,
                progressPercent = 100,
                totalBytesTransferred = totalSize
            )
        }
    }

    private suspend fun executeReceiveFiles(
        peer: PeerSession,
        files: List<TransferProtocol.FileMeta>,
        senderName: String
    ) {
        val startTime = SystemClock.elapsedRealtime()
        val totalSize = files.sumOf { it.size }
        var overallTransferred = 0L
        try {
            _transferState.value = _transferState.value.copy(
                isReceiver = true,
                status = TransferStatus.TRANSFERRING,
                remoteDeviceName = senderName,
                remoteIpAddress = peer.remoteIp,
                incomingProposal = null
            )

            for ((index, expected) in files.withIndex()) {
                if (isCancelled) break
                updateQueueItem(index) { it.copy(status = TransferItemStatus.IN_PROGRESS, transferred = 0) }
                _transferState.value = _transferState.value.copy(
                    currentFileIndex = index + 1,
                    currentFileName = expected.name,
                    currentFileSize = expected.size,
                    currentBytesTransferred = 0
                )

                val metaFrame = TransferProtocol.readFrame(peer.input)
                val received = TransferProtocol.FileMeta.fromJson(JSONObject(metaFrame))
                require(received.index == expected.index && received.size == expected.size && received.name == expected.name) {
                    "File header does not match proposal"
                }

                val outResult = fileManager.createDownloadOutputStream(expected.name, expected.mimeType)
                val buffer = ByteArray(256 * 1024)
                var fileTransferred = 0L
                var lastTick = SystemClock.elapsedRealtime()
                var bytesSinceTick = 0L
                outResult.outputStream.use { output ->
                    while (fileTransferred < expected.size) {
                        if (isCancelled) break
                        while (isPaused) {
                            delay(200)
                            if (isCancelled) break
                        }
                        val toRead = minOf(buffer.size.toLong(), expected.size - fileTransferred).toInt()
                        val read = peer.input.read(buffer, 0, toRead)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        fileTransferred += read
                        overallTransferred += read
                        bytesSinceTick += read
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastTick >= 500) {
                            val bps = bytesSinceTick * 1000 / (now - lastTick)
                            publishProgress(index, fileTransferred, overallTransferred, totalSize, bps)
                            lastTick = now
                            bytesSinceTick = 0
                        }
                    }
                }

                if (fileTransferred != expected.size) {
                    updateQueueItem(index) { it.copy(status = TransferItemStatus.FAILED, transferred = fileTransferred, error = "Incomplete file") }
                    throw IOException("Incomplete receive: ${expected.name} ($fileTransferred/${expected.size})")
                }

                // END_FILE is a framed control message after the exact payload.
                val end = JSONObject(TransferProtocol.readFrame(peer.input))
                require(end.optString("cmd") == TransferProtocol.COMMAND_END_FILE && end.optInt("index") == expected.index) {
                    "Missing end-of-file marker"
                }

                updateQueueItem(index) { it.copy(status = TransferItemStatus.COMPLETED, transferred = expected.size) }
                val category = fileManager.determineCategory(expected.name, expected.mimeType)
                saveHistoryRecord(expected.name, expected.size, expected.mimeType, category, outResult.savedPath, senderName, TransferStatus.COMPLETED, TransferDirection.RECEIVED, SystemClock.elapsedRealtime() - startTime)
                notificationManager.showFileCompleted(expected.name, expected.size, received = true)
            }

            if (isCancelled) {
                _transferState.value = _transferState.value.copy(status = TransferStatus.CANCELLED)
            } else {
                _transferState.value = _transferState.value.copy(
                    status = TransferStatus.COMPLETED,
                    progressPercent = 100,
                    totalBytesTransferred = totalSize
                )
            }
        } catch (e: Exception) {
            Log.e(tag, "Receive files error", e)
            _transferState.value = _transferState.value.copy(
                status = TransferStatus.FAILED,
                errorMessage = e.message ?: "Failed to receive files"
            )
            notificationManager.cancelProgress()
        }
    }

    private fun publishProgress(index: Int, fileBytes: Long, overall: Long, total: Long, bps: Long) {
        val remaining = (total - overall).coerceAtLeast(0)
        val remainingSeconds = if (bps > 0) remaining / bps else 0
        _transferState.value = _transferState.value.copy(
            currentBytesTransferred = fileBytes,
            totalBytesTransferred = overall,
            progressPercent = if (total > 0) ((overall * 100) / total).toInt() else 0,
            speedBps = bps,
            speedText = formatSpeed(bps),
            remainingSeconds = remainingSeconds
        )
        updateQueueItem(index) { it.copy(transferred = fileBytes, status = TransferItemStatus.IN_PROGRESS) }
    }

    private fun updateQueueItem(index: Int, transform: (TransferItemState) -> TransferItemState) {
        val state = _transferState.value
        if (index !in state.queue.indices) return
        val updated = state.queue.toMutableList()
        updated[index] = transform(updated[index])
        _transferState.value = state.copy(queue = updated)
    }

    fun pauseTransfer() {
        isPaused = true
        _transferState.value = _transferState.value.copy(status = TransferStatus.PAUSED)
    }

    fun resumeTransfer() {
        isPaused = false
        _transferState.value = _transferState.value.copy(status = TransferStatus.TRANSFERRING)
    }

    fun cancelTransfer() {
        isCancelled = true
        currentTransferJob?.cancel()
        _transferState.value = _transferState.value.copy(status = TransferStatus.CANCELLED)
        notificationManager.cancelProgress()
        // Do not automatically close the peer session. The user can explicitly Disconnect.
    }

    fun resetState() {
        _transferState.value = ActiveTransferState()
        isPaused = false
        isCancelled = false
    }

    private fun closeSession(expected: PeerSession? = session) {
        val peer = expected ?: return
        peer.running = false
        try { peer.socket.close() } catch (_: Exception) {}
        if (session === peer) {
            session = null
            sessionReaderJob?.cancel()
            sessionReaderJob = null
        }
    }

    private suspend fun saveHistoryRecord(
        fileName: String,
        fileSize: Long,
        mimeType: String,
        category: FileCategory,
        path: String,
        remoteName: String,
        status: TransferStatus,
        direction: TransferDirection,
        durationMs: Long
    ) {
        db.transferDao().insertTransfer(
            TransferEntity(
                fileName = fileName,
                fileSize = fileSize,
                mimeType = mimeType,
                categoryName = category.name,
                localFilePath = path,
                remoteDeviceName = remoteName,
                statusName = status.name,
                directionName = direction.name,
                timestamp = System.currentTimeMillis(),
                durationMs = durationMs
            )
        )
    }

    private fun formatSpeed(bps: Long): String = when {
        bps >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bps / (1024f * 1024f))
        bps >= 1024 -> String.format(Locale.US, "%.0f KB/s", bps / 1024f)
        else -> "$bps B/s"
    }
}

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.content.LocalContentRepository
import com.example.data.database.TransferEntity
import com.example.data.model.FileCategory
import com.example.data.model.SelectedFile
import com.example.data.model.TransferDirection
import com.example.data.repository.SettingsRepository
import com.example.data.repository.TransferHistoryRepository
import com.example.network.transfer.TransferManager
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SendoraDarkBorder
import com.example.ui.theme.SuccessGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class HomeTab(val label: String, val category: FileCategory?) {
    HISTORY("History", null),
    APPS("Apps", FileCategory.APKS),
    PHOTOS("Photos", FileCategory.PHOTOS),
    VIDEOS("Videos", FileCategory.VIDEOS),
    MUSIC("Music", FileCategory.MUSIC)
}

@Composable
fun HomeScreen(
    settingsRepository: SettingsRepository,
    historyRepository: TransferHistoryRepository,
    localContentRepository: LocalContentRepository,
    onNavigateToSend: (FileCategory?) -> Unit,
    onNavigateToReceive: () -> Unit,
    onNavigateToConnect: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToContent: (FileCategory) -> Unit,
    onSendLocalFiles: (List<SelectedFile>) -> Unit,
    transferManager: TransferManager
) {
    val settings by settingsRepository.settings.collectAsStateWithLifecycle()
    val recentTransfers by historyRepository.getRecentTransfers(20).collectAsStateWithLifecycle(initialValue = emptyList())
    val transferState by transferManager.transferState.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf(HomeTab.APPS) }
    var content by remember(selectedTab) { mutableStateOf<List<LocalContentRepository.LocalContentItem>>(emptyList()) }
    var loading by remember(selectedTab) { mutableStateOf(true) }
    var selectedIds by remember(selectedTab) { mutableStateOf<Set<String>>(emptySet()) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(selectedTab) {
        val category = selectedTab.category
        if (category != null) {
            loading = true
            content = localContentRepository.scan(category)
            selectedIds = emptySet()
            loading = false
        }
    }

    val filteredContent = remember(content, query) {
        if (query.isBlank()) content else content.filter { it.name.contains(query, ignoreCase = true) }
    }

    val selectedItems = filteredContent.filter { it.id in selectedIds }
    val selectedSize = selectedItems.sumOf { it.size }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { /* menu reserved for future drawer */ }) {
                        Icon(Icons.Default.Menu, "Menu")
                    }
                    Text(
                        "Transfer",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    IconButton(onClick = { query = if (query.isBlank()) " " else "" }) {
                        Icon(Icons.Default.Search, "Search")
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, "Settings")
                    }
                }
                if (query.isNotBlank()) {
                    androidx.compose.material3.OutlinedTextField(
                        value = query.trim(),
                        onValueChange = { query = it },
                        singleLine = true,
                        placeholder = { Text("Search ${selectedTab.label.lowercase(Locale.US)}") },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(28.dp)
                ) {
                    items(HomeTab.values().toList()) { tab ->
                        HomeTabItem(tab, selectedTab == tab) { selectedTab = tab }
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = .35f)))
            }
        },
        bottomBar = {
            Column {
                if (selectedIds.isNotEmpty() && selectedTab.category != null) {
                    Surface(shadowElevation = 8.dp) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("${selectedIds.size} selected", fontWeight = FontWeight.Bold)
                                Text(formatSize(selectedSize), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            androidx.compose.material3.Button(onClick = {
                                onSendLocalFiles(selectedItems.map {
                                    SelectedFile(it.id, it.uri, it.name, it.size, it.mimeType, it.category)
                                })
                            }) { Text("SEND") }
                        }
                    }
                }
                SendoraBottomBar(
                    onMusic = { selectedTab = HomeTab.MUSIC },
                    onVideos = { selectedTab = HomeTab.VIDEOS },
                    onConnect = onNavigateToConnect,
                    onPhotos = { selectedTab = HomeTab.PHOTOS },
                    onFiles = { onNavigateToContent(FileCategory.DOCUMENTS) }
                )
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            transferState.incomingProposal?.let { proposal ->
                IncomingBanner(
                    sender = proposal.senderName,
                    count = proposal.files.size,
                    onAccept = { transferManager.acceptIncomingTransfer(proposal) },
                    onReject = { transferManager.rejectIncomingTransfer(proposal) }
                )
            }

            if (selectedTab == HomeTab.HISTORY) {
                HistoryHomeContent(recentTransfers, onNavigateToHistory)
            } else {
                LocalCategoryContent(
                    tab = selectedTab,
                    items = filteredContent,
                    loading = loading,
                    selectedIds = selectedIds,
                    onToggle = { id -> selectedIds = if (id in selectedIds) selectedIds - id else selectedIds + id },
                    onSelectAll = { selectedIds = if (selectedIds.size == filteredContent.size) emptySet() else filteredContent.map { it.id }.toSet() },
                    onOpenFull = { selectedTab.category?.let(onNavigateToContent) }
                )
            }
        }
    }
}

@Composable
private fun HomeTabItem(tab: HomeTab, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(tab.label, color = if (selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.width(42.dp).height(3.dp).clip(RoundedCornerShape(3.dp)).background(if (selected) CyanAccent else androidx.compose.ui.graphics.Color.Transparent))
    }
}

@Composable
private fun LocalCategoryContent(
    tab: HomeTab,
    items: List<LocalContentRepository.LocalContentItem>,
    loading: Boolean,
    selectedIds: Set<String>,
    onToggle: (String) -> Unit,
    onSelectAll: () -> Unit,
    onOpenFull: () -> Unit
) {
    if (loading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = CyanAccent) }
        return
    }
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            SectionHeader(title = if (tab == HomeTab.APPS) "Hot" else "On this phone", count = items.size, onSelectAll = onSelectAll)
        }
        if (items.isEmpty()) {
            item {
                EmptyCategoryCard(tab.label)
            }
        } else if (tab == HomeTab.APPS) {
            item {
                LazyRow(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(items.take(2), key = { it.id }) { item -> AppHotCard(item, item.id in selectedIds) { onToggle(item.id) } }
                }
            }
            item { Text("Local", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)) }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.fillMaxWidth().height(((items.drop(2).size + 3) / 4 * 132).coerceAtLeast(132).dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    items(items.drop(2), key = { it.id }) { item -> AppGridItem(item, item.id in selectedIds) { onToggle(item.id) } }
                }
            }
        } else {
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxWidth().height(((items.size + 1) / 2 * 190).coerceAtLeast(190).dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(items, key = { it.id }) { item -> MediaGridItem(item, item.id in selectedIds) { onToggle(item.id) } }
                }
            }
        }
        item {
            Text("Open full ${tab.label.lowercase(Locale.US)}", modifier = Modifier.padding(horizontal = 16.dp).clickable { onOpenFull() }, color = ElectricBlue, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionHeader(title: String, count: Int, onSelectAll: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("$count", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(10.dp))
        IconButton(onClick = onSelectAll, modifier = Modifier.size(38.dp)) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Text("✓", fontSize = 14.sp, color = CyanAccent)
            }
        }
    }
}

@Composable
private fun AppHotCard(item: LocalContentRepository.LocalContentItem, selected: Boolean, onToggle: () -> Unit) {
    Card(
        Modifier.width(210.dp).clickable(onClick = onToggle),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(if (selected) 1.5.dp else 0.dp, CyanAccent)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(item, 58.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                Text(formatSize(item.size), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun AppGridItem(item: LocalContentRepository.LocalContentItem, selected: Boolean, onToggle: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onToggle), horizontalAlignment = Alignment.CenterHorizontally) {
        Box {
            AppIcon(item, 58.dp)
            if (selected) SelectionDot(Modifier.align(Alignment.TopEnd))
        }
        Spacer(Modifier.height(6.dp))
        Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = androidx.compose.ui.text.style.TextAlign.Center, style = MaterialTheme.typography.bodySmall)
        Text(formatSize(item.size), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AppIcon(item: LocalContentRepository.LocalContentItem, size: androidx.compose.ui.unit.Dp) {
    if (item.appIcon != null) {
        androidx.compose.foundation.Image(item.appIcon.asImageBitmap(), item.name, Modifier.size(size).clip(RoundedCornerShape(14.dp)))
    } else {
        Box(Modifier.size(size).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Icon(Icons.Default.Android, null, tint = CyanAccent) }
    }
}

@Composable
private fun MediaGridItem(item: LocalContentRepository.LocalContentItem, selected: Boolean, onToggle: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onToggle),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(if (selected) 1.5.dp else 0.5.dp, if (selected) CyanAccent else SendoraDarkBorder)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(125.dp)) {
                AsyncImage(model = item.uri, contentDescription = item.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                if (selected) SelectionDot(Modifier.align(Alignment.TopEnd).padding(8.dp))
            }
            Column(Modifier.padding(10.dp)) {
                Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                val detail = when (item.category) {
                    FileCategory.VIDEOS -> if (item.durationMs > 0) "${formatSize(item.size)} • ${formatDuration(item.durationMs)}" else formatSize(item.size)
                    FileCategory.MUSIC -> "${formatSize(item.size)}${if (!item.artist.isNullOrBlank()) " • ${item.artist}" else ""}"
                    else -> formatSize(item.size)
                }
                Text(detail, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun SelectionDot(modifier: Modifier = Modifier) {
    Box(modifier.size(24.dp).clip(CircleShape).background(CyanAccent), contentAlignment = Alignment.Center) { Text("✓", color = MaterialTheme.colorScheme.onPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun EmptyCategoryCard(label: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("No $label found", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Sendora is showing content from this phone only.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HistoryHomeContent(items: List<TransferEntity>, onViewAll: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Recent transfers", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)) }
        if (items.isEmpty()) item { EmptyCategoryCard("transfers") }
        items(items) { RecentTransferRow(it) }
        item { Text("View all history", Modifier.clickable { onViewAll() }.padding(vertical = 12.dp), color = ElectricBlue, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun IncomingBanner(sender: String, count: Int, onAccept: () -> Unit, onReject: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(12.dp), colors = CardDefaults.cardColors(containerColor = CyanAccent.copy(alpha = .12f))) {
        Column(Modifier.padding(14.dp)) {
            Text("Incoming transfer", color = CyanAccent, fontWeight = FontWeight.Bold)
            Text("$sender wants to send $count file(s)", fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Text("Reject", Modifier.clickable { onReject() }.padding(10.dp), color = ErrorRed)
                Text("Accept", Modifier.clickable { onAccept() }.padding(10.dp), color = SuccessGreen, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SendoraBottomBar(onMusic: () -> Unit, onVideos: () -> Unit, onConnect: () -> Unit, onPhotos: () -> Unit, onFiles: () -> Unit) {
    Surface(shadowElevation = 10.dp, tonalElevation = 4.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            BottomNavItem("Music", Icons.Default.AudioFile, onMusic)
            BottomNavItem("Videos", Icons.Default.Movie, onVideos)
            Box(Modifier.size(58.dp).clip(CircleShape).background(CyanAccent).clickable(onClick = onConnect), contentAlignment = Alignment.Center) { Icon(Icons.Default.Link, "Connect", tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(30.dp)) }
            BottomNavItem("Photos", Icons.Default.Image, onPhotos)
            BottomNavItem("Files", Icons.Default.Folder, onFiles)
        }
    }
}

@Composable
private fun BottomNavItem(label: String, icon: ImageVector, onClick: () -> Unit) {
    Column(Modifier.width(64.dp).clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, modifier = Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun RecentTransferRow(item: TransferEntity) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(CyanAccent.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                Icon(if (item.direction == TransferDirection.SENT) Icons.Default.Link else Icons.Default.History, null, tint = CyanAccent)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(item.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Text("${if (item.direction == TransferDirection.SENT) "Sent" else "Received"} • ${formatSize(item.fileSize)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(item.timestamp)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.1f GB", bytes / (1024f * 1024f * 1024f))
    bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
    bytes >= 1024 -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
    else -> "$bytes B"
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

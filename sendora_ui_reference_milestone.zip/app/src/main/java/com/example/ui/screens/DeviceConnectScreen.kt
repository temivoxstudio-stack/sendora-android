package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Device
import com.example.data.model.SelectedFile
import com.example.data.repository.SettingsRepository
import com.example.network.discovery.DeviceDiscoveryManager
import com.example.network.transfer.TransferManager
import com.example.qr.QrScannerView
import com.example.ui.components.RadarPulseAnimation
import com.example.ui.components.SendoraActionButton
import com.example.ui.components.SendoraCard
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SendoraDarkBorder
import org.json.JSONObject

@Composable
fun DeviceConnectScreen(
    selectedFiles: List<SelectedFile>,
    settingsRepository: SettingsRepository,
    discoveryManager: DeviceDiscoveryManager,
    transferManager: TransferManager,
    onBack: () -> Unit,
    onTransferStarted: () -> Unit
) {
    val settings by settingsRepository.settings.collectAsStateWithLifecycle()
    val discoveredDevices by discoveryManager.discoveredDevices.collectAsStateWithLifecycle()

    var showCameraScanner by remember { mutableStateOf(false) }
    var showManualIpDialog by remember { mutableStateOf(false) }
    var manualIpInput by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        // Keep a local listener ready as well: either side may initiate the next transfer.
        transferManager.startServer(settings.deviceName)
        discoveryManager.startDiscovery(settings.deviceName)
    }

    fun startTransferToDevice(ip: String, port: Int = 8888) {
        transferManager.sendFilesToDevice(
            targetIp = ip,
            targetPort = port,
            files = selectedFiles,
            myDeviceName = settings.deviceName
        )
        onTransferStarted()
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Text(
                    text = "Connect Device",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    ) { innerPadding ->
        if (showCameraScanner) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                QrScannerView(
                    onQrScanned = { payloadStr ->
                        try {
                            val json = JSONObject(payloadStr)
                            if (json.optString("app") == "SENDORA") {
                                val targetIp = json.getString("ip")
                                val targetPort = json.optInt("port", 8888)
                                showCameraScanner = false
                                startTransferToDevice(targetIp, targetPort)
                            }
                        } catch (e: Exception) {}
                    }
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Radar animation card
                item {
                    SendoraCard(
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "radar_discovery_card"
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadarPulseAnimation(sizeDp = 180.dp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Searching for Nearby Sendora Devices...",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Ensure receiver device has Sendora open or same Wi-Fi / Hotspot connected",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    }
                }

                // QR Scanner and Manual Code Fallback
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SendoraActionButton(
                            text = "Scan QR Code",
                            onClick = { showCameraScanner = true },
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.QrCodeScanner,
                            containerColor = ElectricBlue,
                            testTag = "scan_qr_to_connect_button"
                        )

                        SendoraActionButton(
                            text = "Manual IP / Code",
                            onClick = { showManualIpDialog = true },
                            modifier = Modifier.weight(1f),
                            icon = Icons.Default.Key,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = CyanAccent,
                            testTag = "manual_ip_button"
                        )
                    }
                }

                // Discovered Devices List Header
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Discovered Devices (${discoveredDevices.size})",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        IconButton(onClick = { discoveryManager.startDiscovery(settings.deviceName) }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh discovery",
                                tint = ElectricBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                if (discoveredDevices.isEmpty()) {
                    item {
                        SendoraCard(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Devices,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No nearby devices found yet",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Tap 'Scan QR Code' to pair instantly with phone camera",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyanAccent
                                )
                            }
                        }
                    }
                } else {
                    items(discoveredDevices) { device ->
                        DeviceItemRow(
                            device = device,
                            onClick = { startTransferToDevice(device.ipAddress, device.port) }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }

        // Manual IP Dialog
        if (showManualIpDialog) {
            AlertDialog(
                onDismissRequest = { showManualIpDialog = false },
                title = { Text("Connect via Local IP Address") },
                text = {
                    Column {
                        Text("Enter receiver phone's local IP address (e.g. 192.168.1.15):")
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = manualIpInput,
                            onValueChange = { manualIpInput = it },
                            label = { Text("IP Address") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showManualIpDialog = false
                            if (manualIpInput.isNotBlank()) {
                                startTransferToDevice(manualIpInput.trim())
                            }
                        },
                        enabled = manualIpInput.isNotBlank()
                    ) {
                        Text("Connect & Send")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showManualIpDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun DeviceItemRow(
    device: Device,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("device_item_${device.name.lowercase()}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, SendoraDarkBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(ElectricBlue.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Devices,
                    contentDescription = null,
                    tint = ElectricBlue,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = device.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Local IP: ${device.ipAddress}:${device.port}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Select",
                tint = CyanAccent,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

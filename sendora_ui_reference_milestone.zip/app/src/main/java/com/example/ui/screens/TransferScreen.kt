package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TransferStatus
import com.example.network.transfer.TransferManager
import com.example.ui.components.ProgressBarWithGlow
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SendoraDarkBorder
import java.util.Locale

@Composable
fun TransferScreen(
    transferManager: TransferManager,
    onTransferComplete: () -> Unit,
    onCancel: () -> Unit
) {
    val state by transferManager.transferState.collectAsStateWithLifecycle()
    val isCompleted = state.status == TransferStatus.COMPLETED

    Scaffold { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isCompleted) "TRANSFER COMPLETE" else if (state.isReceiver) "RECEIVING" else "SENDING",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp),
                    color = CyanAccent
                )
                Text(
                    text = state.remoteDeviceName.ifEmpty { "Sendora Device" },
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (state.remoteDeviceName.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(CyanAccent))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "CONNECTED • ${state.remoteIpAddress}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanAccent
                        )
                    }
                }
            }

            state.incomingProposal?.let { proposal ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = ElectricBlue.copy(alpha = .12f)),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("INCOMING TRANSFER", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = CyanAccent)
                            Spacer(Modifier.height(4.dp))
                            Text("${proposal.senderName} wants to send ${proposal.files.size} file(s)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text("Total • ${formatSize(proposal.totalSize)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(onClick = { transferManager.rejectIncomingTransfer(proposal) }, modifier = Modifier.weight(1f)) { Text("REJECT") }
                                Button(onClick = { transferManager.acceptIncomingTransfer(proposal) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)) { Text("ACCEPT") }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SendoraDarkBorder),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(72.dp).clip(CircleShape).background(ElectricBlue.copy(alpha = .15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.SwapHoriz,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(42.dp)
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            text = if (isCompleted) "Connection remains active" else "${state.progressPercent}%",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (!isCompleted) {
                            Text(
                                text = state.currentFileName.ifEmpty { "Preparing files…" },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                            Text(
                                text = "File ${state.currentFileIndex} of ${state.filesCount}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(14.dp))
                            ProgressBarWithGlow(state.progressPercent, 12.dp)
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                MetricBox("Speed", state.speedText)
                                MetricBox("Remaining", if (state.remainingSeconds > 0) "${state.remainingSeconds}s" else "—")
                                MetricBox("Transferred", "${formatSize(state.totalBytesTransferred)} / ${formatSize(state.totalSize)}")
                            }
                        } else {
                            Text(
                                text = "You can send or receive again without reconnecting.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "TRANSFER QUEUE",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            items(state.queue, key = { it.index }) { item ->
                val statusText = when (item.status) {
                    TransferManager.TransferItemStatus.WAITING -> "Waiting"
                    TransferManager.TransferItemStatus.IN_PROGRESS -> "${item.progressPercent}% • In progress"
                    TransferManager.TransferItemStatus.COMPLETED -> "100% • Completed"
                    TransferManager.TransferItemStatus.FAILED -> "Failed"
                    TransferManager.TransferItemStatus.CANCELLED -> "Cancelled"
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .45f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (item.status == TransferManager.TransferItemStatus.COMPLETED) Icons.Default.CheckCircle else Icons.Default.SwapHoriz,
                                contentDescription = null,
                                tint = if (item.status == TransferManager.TransferItemStatus.COMPLETED) CyanAccent else ElectricBlue,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, maxLines = 1, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                Text("${formatSize(item.size)} • $statusText", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        if (item.status == TransferManager.TransferItemStatus.IN_PROGRESS) {
                            Spacer(Modifier.height(8.dp))
                            ProgressBarWithGlow(item.progressPercent, 8.dp)
                        }
                    }
                }
            }

            state.errorMessage?.let { error ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = ErrorRed.copy(alpha = .12f)), modifier = Modifier.fillMaxWidth()) {
                        Text(error, color = ErrorRed, modifier = Modifier.padding(14.dp))
                    }
                }
            }

            item {
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!isCompleted && state.status == TransferStatus.TRANSFERRING) {
                        Button(
                            onClick = { transferManager.pauseTransfer() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Icon(Icons.Default.Pause, null)
                            Spacer(Modifier.width(6.dp)); Text("PAUSE")
                        }
                    } else if (state.status == TransferStatus.PAUSED) {
                        Button(onClick = { transferManager.resumeTransfer() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)) {
                            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("RESUME")
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            transferManager.disconnect()
                            onCancel()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Close, null)
                        Spacer(Modifier.width(6.dp)); Text("DISCONNECT")
                    }
                }
            }

            if (isCompleted) {
                item {
                    Button(
                        onClick = onTransferComplete,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("SEND / RECEIVE MORE")
                    }
                }
            } else if (state.status == TransferStatus.FAILED || state.status == TransferStatus.CANCELLED || state.status == TransferStatus.REJECTED) {
                item {
                    Button(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("BACK") }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MetricBox(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = CyanAccent)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.1f GB", bytes / (1024f * 1024f * 1024f))
    bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
    bytes >= 1024 -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
    else -> "$bytes B"
}

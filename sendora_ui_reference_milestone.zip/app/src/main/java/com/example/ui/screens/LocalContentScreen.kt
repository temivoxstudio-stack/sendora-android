package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.content.LocalContentRepository
import com.example.data.model.FileCategory
import com.example.ui.components.SendoraCard
import com.example.ui.theme.CyanAccent
import java.util.Locale

@Composable
fun LocalContentScreen(
    repository: LocalContentRepository,
    category: FileCategory,
    onBack: () -> Unit
) {
    var items by remember(category) { mutableStateOf<List<LocalContentRepository.LocalContentItem>>(emptyList()) }
    var loading by remember(category) { mutableStateOf(true) }
    var selected by remember(category) { mutableStateOf<Set<String>>(emptySet()) }
    var refreshKey by remember(category) { mutableStateOf(0) }

    LaunchedEffect(category, refreshKey) {
        loading = true
        items = repository.scan(category)
        selected = emptySet()
        loading = false
    }

    val title = when (category) {
        FileCategory.APKS -> "Apps"
        FileCategory.PHOTOS -> "Photos"
        FileCategory.VIDEOS -> "Videos"
        FileCategory.MUSIC -> "Music"
        FileCategory.DOCUMENTS -> "Files & Documents"
        FileCategory.ZIPS -> "ZIP & Archives"
        FileCategory.OTHER -> "Other Files"
    }

    Scaffold(
        topBar = {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleLarge)
                    Text("This phone's content • ${items.size} items", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                }
                IconButton(onClick = {
                    refreshKey++
                }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                }
            }
        }
    ) { padding ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CyanAccent)
            }
        } else if (items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding).padding(24.dp), contentAlignment = Alignment.Center) {
                SendoraCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Nothing found", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "No accessible ${title.lowercase(Locale.US)} were found on this phone. Android permissions may limit what can be scanned.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("${selected.size} selected", style = MaterialTheme.typography.labelLarge, color = CyanAccent)
                        IconButton(onClick = { selected = items.map { it.id }.toSet() }) {
                            Text("ALL", style = MaterialTheme.typography.labelSmall, color = CyanAccent)
                        }
                    }
                }
                items(items, key = { it.id }) { item ->
                    LocalContentRow(
                        item = item,
                        selected = item.id in selected,
                        onToggle = {
                            selected = if (item.id in selected) selected - item.id else selected + item.id
                        }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun LocalContentRow(
    item: LocalContentRepository.LocalContentItem,
    selected: Boolean,
    onToggle: () -> Unit
) {
    SendoraCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (item.appIcon != null) {
                Image(item.appIcon.asImageBitmap(), contentDescription = item.name, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
            } else {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(categoryIcon(item.category), contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, maxLines = 1, style = MaterialTheme.typography.bodyMedium)
                val extra = when {
                    item.category == FileCategory.MUSIC && !item.artist.isNullOrBlank() -> item.artist
                    item.category == FileCategory.VIDEOS && item.durationMs > 0 -> formatDuration(item.durationMs)
                    else -> null
                }
                Text(
                    buildString {
                        append(formatSize(item.size))
                        if (!extra.isNullOrBlank()) append(" • ").append(extra)
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Checkbox(checked = selected, onCheckedChange = { onToggle() })
        }
    }
}

private fun categoryIcon(category: FileCategory) = when (category) {
    FileCategory.APKS -> Icons.Default.Android
    FileCategory.PHOTOS -> Icons.Default.Image
    FileCategory.VIDEOS -> Icons.Default.Movie
    FileCategory.MUSIC -> Icons.Default.AudioFile
    else -> Icons.Default.Description
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.2f GB", bytes / (1024f * 1024f * 1024f))
    bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
    bytes >= 1024 -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
    else -> "$bytes B"
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}

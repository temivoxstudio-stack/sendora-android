# Sendora Implementation Status — Milestone 1

Date: 2026-08-11

## Existing project preserved

This milestone modifies the existing Android/Kotlin/Jetpack Compose Sendora project. The original uploaded ZIP was not overwritten.

## Completed in this milestone

### Persistent connection
- Added a persistent peer session around the existing TCP transfer foundation.
- Socket is no longer closed when one transfer batch finishes.
- The same connection can be reused for later transfer requests.
- Either peer can initiate the next transfer on the established session.
- Explicit DISCONNECT closes the session.
- Handshake/session framing was upgraded to protocol version 2.0.

### Queue
- Added per-file queue state.
- Each file exposes waiting/in-progress/completed/failed/cancelled status and progress.
- Transfer screen now displays the individual queue.
- Increased transfer buffer from 64 KiB to 256 KiB and enabled TCP_NODELAY.

### Notifications
- Removed progress notification spam.
- Completion notifications are generated per completed file.

### Local content
- Added local scanners for Apps, Photos, Videos, Music and accessible documents/archives.
- Home category cards now open the phone's own local content browser.
- Installed launchable apps show their icon, name and APK size where Android exposes the source APK.
- FileManager can open local APK file URIs.

### Incoming transfers
- Incoming requests can be accepted/rejected from Home or the Transfer screen, so the second direction does not require returning to a dedicated Receive screen.

### Permissions
- Added version-aware requests for modern media permissions and legacy external-storage read permission.

## Not yet completed

This is an implementation milestone, not the final release.

- Full bottom navigation redesign and final visual polish.
- Direct Send integration from every local-content list with bulk selection.
- Advanced thumbnail caching/paging for very large libraries.
- Robust retry/resume after interrupted transfers.
- Foreground-service/background transfer support where appropriate.
- Full connection screen with persistent connected-device controls.
- Extensive two-device testing and performance profiling.
- Final APK/AAB build.

## Build note

The uploaded project does not include a Gradle wrapper, and this execution environment does not have an Android SDK/Gradle build toolchain available. Therefore this milestone was source-implemented and structurally checked, but a release APK was not produced here.

Open the project in Android Studio, sync Gradle, and run it on two real Android phones for the required network validation.

# Sendora Transfer Architecture — Milestone 1

This build moves the transfer layer toward the requested persistent two-way session.

## Implemented

- Persistent TCP peer session instead of closing the socket after every batch.
- Framed protocol upgraded to protocol version 2.0.
- One socket can carry multiple sequential transfer requests.
- Either side can initiate a new transfer on the existing session.
- TCP_NODELAY enabled for the peer socket.
- 256 KiB file buffer used for the transfer loop.
- Per-file queue state exposed to the Compose UI.
- Transfer screen shows each file as Waiting / In progress / Completed / Failed / Cancelled.
- Connection remains active after a transfer completes.
- Explicit DISCONNECT action closes the peer session.
- Incoming transfer prompts are visible from the Home screen and Transfer screen, not only Receive.
- Progress notifications are disabled; completed-file notifications are emitted individually.
- Local content scanner added for Apps, Photos, Videos, Music and accessible documents/archives.
- Home category cards now open the phone's own local content browser.
- APK/app entries use the installed application's source APK where Android exposes it.
- FileManager can open file:// APK URIs for local sending.
- Modern media permissions are requested according to Android version.

## Important Android limitations

Android does not allow every app to silently enable Wi-Fi/hotspot functionality on every device/version. The app therefore keeps discovery and connection setup automatic where the platform permits it and retains QR/manual discovery fallbacks.

Android app packaging also varies. Not every installed application can necessarily be represented by one standalone APK because some apps use split APKs.

## Still required in the next milestones

- Full polished bottom navigation/home redesign.
- Better media thumbnails and large-library paging/caching.
- Dedicated app selection/send integration from the local Apps browser.
- Richer per-file queue controls and resume/retry semantics.
- Connection screen showing the persistent session and SEND / RECEIVE / DISCONNECT actions.
- More comprehensive storage/permission/error handling.
- Background/foreground-service behavior for long transfers where appropriate.
- Extensive two-device testing, including A → B → A without reconnecting.
- Release APK/AAB build and real-device performance testing.

# Sendora transfer fixes

This build keeps the AI Studio project structure and fixes the most important local-transfer framing issue found during review.

## Fixed
- Replaced mixed `BufferedReader`/`DataInputStream` use on the same socket with length-prefixed UTF-8 control frames.
- File payloads are read/written as exact byte counts, preventing reader buffering from consuming binary file bytes.
- Receiver validates each incoming file header against the original proposal.
- Sender and receiver reject incomplete file transfers instead of recording them as completed.
- Receiver filenames are sanitized before being written to shared storage.
- Sender now fails clearly if a selected file cannot be opened instead of leaving the receiver waiting indefinitely.

## Important
This ZIP has not been compiled in this environment because an Android SDK/Gradle toolchain is not available here. Build it in a real Android/Gradle environment before treating it as production-ready.

The app still needs real-device testing on two Android phones, especially discovery over the intended Wi-Fi/hotspot setup, QR pairing, large files, disconnect/retry behavior, and Android-version-specific permissions.

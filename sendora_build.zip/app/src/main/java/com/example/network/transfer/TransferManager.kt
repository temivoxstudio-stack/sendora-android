package com.example.network.transfer

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.database.AppDatabase
import com.example.data.database.TransferEntity
import com.example.data.model.FileCategory
import com.example.data.model.SelectedFile
import com.example.data.model.TransferDirection
import com.example.data.model.TransferStatus
import com.example.notifications.SendoraNotificationManager
import com.example.storage.FileManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.Locale

class TransferManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val TAG = "SendoraTransferManager"
    private val fileManager = FileManager(context)
    private val notificationManager = SendoraNotificationManager(context)
    private val db = AppDatabase.getInstance(context)

    data class IncomingProposal(
        val senderName: String,
        val files: List<TransferProtocol.FileMeta>,
        val totalSize: Long,
        val socket: Socket
    )

    data class ActiveTransferState(
        val isReceiver: Boolean = false,
        val status: TransferStatus = TransferStatus.PENDING,
        val remoteDeviceName: String = "",
        val filesCount: Int = 0,
        val currentFileIndex: Int = 0,
        val currentFileName: String = "",
        val currentFileSize: Long = 0,
        val currentBytesTransferred: Long = 0,
        val totalSize: Long = 0,
        val totalBytesTransferred: Long = 0,
        val speedBps: Long = 0,
        val speedText: String = "0 KB/s",
        val progressPercent: Int = 0,
        val remainingSeconds: Long = 0,
        val errorMessage: String? = null,
        val incomingProposal: IncomingProposal? = null
    )

    private val _transferState = MutableStateFlow(ActiveTransferState())
    val transferState: StateFlow<ActiveTransferState> = _transferState.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var currentSocket: Socket? = null
    private var currentTransferJob: Job? = null

    @Volatile
    private var isPaused = false
    @Volatile
    private var isCancelled = false

    fun startServer(deviceName: String, port: Int = 8888) {
        stopServer()
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket(port)
                Log.d(TAG, "Server socket started on port $port")

                while (isActive) {
                    val socket = serverSocket?.accept() ?: break
                    Log.d(TAG, "Accepted connection from ${socket.inetAddress}")
                    handleIncomingConnection(socket, deviceName)
                }
            } catch (e: Exception) {
                if (isActive) Log.e(TAG, "Server socket error: ${e.message}")
            }
        }
    }

    fun stopServer() {
        serverJob?.cancel()
        serverJob = null
        try {
            serverSocket?.close()
        } catch (e: Exception) {}
        serverSocket = null
    }

    private suspend fun handleIncomingConnection(socket: Socket, deviceName: String) = withContext(Dispatchers.IO) {
        try {
            val input = DataInputStream(socket.getInputStream())
            val json = JSONObject(TransferProtocol.readFrame(input))
            val cmd = json.optString("cmd")

            if (cmd == TransferProtocol.COMMAND_PROPOSE_FILES) {
                val senderName = json.optString("deviceName", "Sender Device")
                val filesJson = json.optJSONArray("files") ?: throw IllegalArgumentException("Missing files")
                val fileMetas = mutableListOf<TransferProtocol.FileMeta>()
                var totalSize = 0L

                for (i in 0 until filesJson.length()) {
                    val meta = TransferProtocol.FileMeta.fromJson(filesJson.getJSONObject(i))
                    require(meta.size >= 0) { "Invalid file size" }
                    fileMetas.add(meta)
                    totalSize = Math.addExact(totalSize, meta.size)
                }

                val proposal = IncomingProposal(
                    senderName = senderName,
                    files = fileMetas,
                    totalSize = totalSize,
                    socket = socket
                )

                _transferState.value = _transferState.value.copy(
                    incomingProposal = proposal,
                    remoteDeviceName = senderName
                )
            } else {
                socket.close()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling connection: ${e.message}")
            try { socket.close() } catch (_: Exception) {}
        }
    }

    fun acceptIncomingTransfer(proposal: IncomingProposal) {
        _transferState.value = _transferState.value.copy(
            incomingProposal = null,
            status = TransferStatus.TRANSFERRING,
            isReceiver = true,
            remoteDeviceName = proposal.senderName,
            filesCount = proposal.files.size,
            totalSize = proposal.totalSize,
            totalBytesTransferred = 0,
            progressPercent = 0
        )

        currentSocket = proposal.socket
        currentTransferJob = scope.launch(Dispatchers.IO) {
            executeReceiveFiles(proposal.socket, proposal.files, proposal.senderName)
        }
    }

    fun rejectIncomingTransfer(proposal: IncomingProposal) {
        _transferState.value = _transferState.value.copy(incomingProposal = null)
        scope.launch(Dispatchers.IO) {
            try {
                val output = DataOutputStream(proposal.socket.getOutputStream())
                TransferProtocol.writeFrame(
                    output,
                    TransferProtocol.buildResponse(TransferProtocol.COMMAND_REJECT_FILES, "Rejected by user")
                )
            } catch (_: Exception) {
            } finally {
                try { proposal.socket.close() } catch (_: Exception) {}
            }
        }
    }

    fun sendFilesToDevice(targetIp: String, targetPort: Int, files: List<SelectedFile>, myDeviceName: String) {
        isPaused = false
        isCancelled = false

        val fileMetas = files.mapIndexed { idx, sf ->
            TransferProtocol.FileMeta(
                index = idx,
                name = sf.name,
                size = sf.size,
                mimeType = sf.mimeType,
                categoryName = sf.category.name
            )
        }

        val totalSize = files.sumOf { it.size }

        _transferState.value = ActiveTransferState(
            isReceiver = false,
            status = TransferStatus.CONNECTING,
            remoteDeviceName = "Target Device",
            filesCount = files.size,
            totalSize = totalSize,
            totalBytesTransferred = 0,
            progressPercent = 0
        )

        currentTransferJob = scope.launch(Dispatchers.IO) {
            try {
                val socket = Socket(targetIp, targetPort)
                currentSocket = socket
                val output = DataOutputStream(socket.getOutputStream())
                val input = DataInputStream(socket.getInputStream())

                // Send proposal as a framed control message.
                val proposalJson = TransferProtocol.buildProposeFiles(myDeviceName, fileMetas)
                TransferProtocol.writeFrame(output, proposalJson)

                _transferState.value = _transferState.value.copy(status = TransferStatus.CONNECTING)

                // Wait until the receiver explicitly accepts or rejects.
                val respJson = JSONObject(TransferProtocol.readFrame(input))
                if (respJson.optString("cmd") == TransferProtocol.COMMAND_REJECT_FILES) {
                    _transferState.value = _transferState.value.copy(
                        status = TransferStatus.REJECTED,
                        errorMessage = "Receiver rejected file transfer request"
                    )
                    socket.close()
                    return@launch
                }
                if (respJson.optString("cmd") != TransferProtocol.COMMAND_ACCEPT_FILES) {
                    throw IllegalStateException("Unexpected receiver response")
                }

                _transferState.value = _transferState.value.copy(status = TransferStatus.TRANSFERRING)

                val dataOut = output
                var overallTransferred = 0L
                val startTime = System.currentTimeMillis()

                for ((idx, file) in files.withIndex()) {
                    if (isCancelled) break

                    _transferState.value = _transferState.value.copy(
                        currentFileIndex = idx + 1,
                        currentFileName = file.name,
                        currentFileSize = file.size,
                        currentBytesTransferred = 0
                    )

                    val meta = fileMetas[idx]
                    // Write a framed file header before the exact binary payload.
                    TransferProtocol.writeFrame(output, meta.toJson().toString())

                    val inStream = fileManager.openInputStream(file.uri)
                        ?: throw IllegalStateException("Cannot open selected file: ${file.name}")

                    val buffer = ByteArray(64 * 1024)
                    var bytesRead: Int
                    var fileTransferred = 0L
                    var lastSpeedUpdate = System.currentTimeMillis()
                    var bytesSinceLastUpdate = 0L

                    inStream.use { stream ->
                        while (stream.read(buffer).also { bytesRead = it } != -1) {
                            if (isCancelled) break
                            while (isPaused) {
                                delay(200)
                                if (isCancelled) break
                            }

                            dataOut.write(buffer, 0, bytesRead)
                            dataOut.flush()

                            fileTransferred += bytesRead
                            overallTransferred += bytesRead
                            bytesSinceLastUpdate += bytesRead

                            val now = System.currentTimeMillis()
                            val timeDiff = now - lastSpeedUpdate
                            if (timeDiff >= 500) {
                                val bps = (bytesSinceLastUpdate * 1000) / timeDiff
                                val percent = if (totalSize > 0) ((overallTransferred * 100) / totalSize).toInt() else 0
                                val remBytes = totalSize - overallTransferred
                                val remSecs = if (bps > 0) remBytes / bps else 0

                                val speedTxt = formatSpeed(bps)
                                _transferState.value = _transferState.value.copy(
                                    currentBytesTransferred = fileTransferred,
                                    totalBytesTransferred = overallTransferred,
                                    progressPercent = percent,
                                    speedBps = bps,
                                    speedText = speedTxt,
                                    remainingSeconds = remSecs
                                )

                                notificationManager.showTransferProgress(file.name, percent, speedTxt)

                                lastSpeedUpdate = now
                                bytesSinceLastUpdate = 0
                            }
                        }
                    }

                    if (isCancelled) break

                    if (fileTransferred != file.size) {
                        throw IllegalStateException(
                            "Incomplete send: ${file.name} ($fileTransferred/${file.size} bytes)"
                        )
                    }

                    // Save history record
                    saveHistoryRecord(
                        fileName = file.name,
                        fileSize = file.size,
                        mimeType = file.mimeType,
                        category = file.category,
                        path = file.uri.toString(),
                        remoteName = "Target Device",
                        status = TransferStatus.COMPLETED,
                        direction = TransferDirection.SENT,
                        durationMs = System.currentTimeMillis() - startTime
                    )
                }

                if (isCancelled) {
                    _transferState.value = _transferState.value.copy(status = TransferStatus.CANCELLED)
                    notificationManager.cancelProgress()
                } else {
                    _transferState.value = _transferState.value.copy(
                        status = TransferStatus.COMPLETED,
                        progressPercent = 100
                    )
                    val totalDuration = System.currentTimeMillis() - startTime
                    notificationManager.showTransferCompleted(
                        fileName = files.firstOrNull()?.name ?: "Files",
                        totalFiles = files.size,
                        totalSizeText = formatSize(totalSize)
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Send files error: ${e.message}")
                _transferState.value = _transferState.value.copy(
                    status = TransferStatus.FAILED,
                    errorMessage = e.message ?: "Transfer failed"
                )
                notificationManager.cancelProgress()
            } finally {
                currentSocket?.close()
                currentSocket = null
            }
        }
    }

    private suspend fun executeReceiveFiles(
        socket: Socket,
        files: List<TransferProtocol.FileMeta>,
        senderName: String
    ) = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            val dataIn = DataInputStream(socket.getInputStream())
            val dataOut = DataOutputStream(socket.getOutputStream())

            // Accept response. The sender waits for this before sending file bytes.
            TransferProtocol.writeFrame(
                dataOut,
                TransferProtocol.buildResponse(TransferProtocol.COMMAND_ACCEPT_FILES, "Accepted")
            )

            val totalSize = files.sumOf { it.size }
            var overallTransferred = 0L

            for ((idx, fileMeta) in files.withIndex()) {
                if (isCancelled) break

                _transferState.value = _transferState.value.copy(
                    currentFileIndex = idx + 1,
                    currentFileName = fileMeta.name,
                    currentFileSize = fileMeta.size,
                    currentBytesTransferred = 0
                )

                // Read the framed file header. Do not use a Reader here: it may buffer binary bytes.
                val metaLine = TransferProtocol.readFrame(dataIn)
                val receivedMeta = TransferProtocol.FileMeta.fromJson(JSONObject(metaLine))
                if (receivedMeta.index != fileMeta.index || receivedMeta.size != fileMeta.size || receivedMeta.name != fileMeta.name) {
                    throw IllegalStateException("File header does not match the proposal")
                }

                val outResult = fileManager.createDownloadOutputStream(fileMeta.name, fileMeta.mimeType)
                val buffer = ByteArray(64 * 1024)
                var fileTransferred = 0L
                var lastSpeedUpdate = System.currentTimeMillis()
                var bytesSinceLastUpdate = 0L

                outResult.outputStream.use { outStream ->
                    while (fileTransferred < fileMeta.size) {
                        if (isCancelled) break
                        while (isPaused) {
                            delay(200)
                            if (isCancelled) break
                        }

                        val remainingForFile = fileMeta.size - fileTransferred
                        val toRead = if (remainingForFile < buffer.size) remainingForFile.toInt() else buffer.size

                        val readCount = dataIn.read(buffer, 0, toRead)
                        if (readCount == -1) break

                        outStream.write(buffer, 0, readCount)
                        fileTransferred += readCount
                        overallTransferred += readCount
                        bytesSinceLastUpdate += readCount

                        val now = System.currentTimeMillis()
                        val timeDiff = now - lastSpeedUpdate
                        if (timeDiff >= 500) {
                            val bps = (bytesSinceLastUpdate * 1000) / timeDiff
                            val percent = if (totalSize > 0) ((overallTransferred * 100) / totalSize).toInt() else 0
                            val remBytes = totalSize - overallTransferred
                            val remSecs = if (bps > 0) remBytes / bps else 0

                            val speedTxt = formatSpeed(bps)
                            _transferState.value = _transferState.value.copy(
                                currentBytesTransferred = fileTransferred,
                                totalBytesTransferred = overallTransferred,
                                progressPercent = percent,
                                speedBps = bps,
                                speedText = speedTxt,
                                remainingSeconds = remSecs
                            )

                            notificationManager.showTransferProgress(fileMeta.name, percent, speedTxt)

                            lastSpeedUpdate = now
                            bytesSinceLastUpdate = 0
                        }
                    }
                }

                if (fileTransferred != fileMeta.size) {
                    throw IllegalStateException(
                        "Incomplete file: ${fileMeta.name} ($fileTransferred/${fileMeta.size} bytes)"
                    )
                }

                val category = fileManager.determineCategory(fileMeta.name, fileMeta.mimeType)
                saveHistoryRecord(
                    fileName = fileMeta.name,
                    fileSize = fileMeta.size,
                    mimeType = fileMeta.mimeType,
                    category = category,
                    path = outResult.savedPath,
                    remoteName = senderName,
                    status = TransferStatus.COMPLETED,
                    direction = TransferDirection.RECEIVED,
                    durationMs = System.currentTimeMillis() - startTime
                )
            }

            if (isCancelled) {
                _transferState.value = _transferState.value.copy(status = TransferStatus.CANCELLED)
                notificationManager.cancelProgress()
            } else {
                _transferState.value = _transferState.value.copy(
                    status = TransferStatus.COMPLETED,
                    progressPercent = 100
                )
                notificationManager.showTransferCompleted(
                    fileName = files.firstOrNull()?.name ?: "Received Files",
                    totalFiles = files.size,
                    totalSizeText = formatSize(totalSize)
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Execute receive files error: ${e.message}")
            _transferState.value = _transferState.value.copy(
                status = TransferStatus.FAILED,
                errorMessage = e.message ?: "Failed to receive files"
            )
            notificationManager.cancelProgress()
        } finally {
            socket.close()
            currentSocket = null
        }
    }

    fun pauseTransfer() {
        isPaused = true
        _transferState.value = _transferState.value.copy(status = TransferStatus.PAUSED)
    }

    fun resumeTransfer() {
        isPaused = false
        _transferState.value = _transferState.value.copy(status = TransferStatus.TRANSFERRING)
    }

    fun cancelTransfer() {
        isCancelled = true
        currentTransferJob?.cancel()
        currentSocket?.close()
        currentSocket = null
        _transferState.value = _transferState.value.copy(status = TransferStatus.CANCELLED)
        notificationManager.cancelProgress()
    }

    fun resetState() {
        _transferState.value = ActiveTransferState()
    }

    private suspend fun saveHistoryRecord(
        fileName: String,
        fileSize: Long,
        mimeType: String,
        category: FileCategory,
        path: String,
        remoteName: String,
        status: TransferStatus,
        direction: TransferDirection,
        durationMs: Long
    ) {
        val entity = TransferEntity(
            fileName = fileName,
            fileSize = fileSize,
            mimeType = mimeType,
            categoryName = category.name,
            localFilePath = path,
            remoteDeviceName = remoteName,
            statusName = status.name,
            directionName = direction.name,
            timestamp = System.currentTimeMillis(),
            durationMs = durationMs
        )
        db.transferDao().insertTransfer(entity)
    }

    private fun formatSpeed(bps: Long): String {
        return when {
            bps >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bps / (1024f * 1024f))
            bps >= 1024 -> String.format(Locale.US, "%.0f KB/s", bps / 1024f)
            else -> "$bps B/s"
        }
    }

    private fun formatSize(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.2f GB", bytes / (1024f * 1024f * 1024f))
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
            bytes >= 1024 -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
            else -> "$bytes B"
        }
    }
}

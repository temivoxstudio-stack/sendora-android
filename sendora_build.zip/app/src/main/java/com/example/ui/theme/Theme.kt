package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    primaryContainer = SendoraDarkSurfaceVariant,
    onPrimaryContainer = CyanAccentLight,
    secondary = CyanAccent,
    onSecondary = SendoraDarkBg,
    tertiary = PurpleAccent,
    background = SendoraDarkBg,
    onBackground = TextPrimaryDark,
    surface = SendoraDarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = SendoraDarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = SendoraDarkBorder,
    error = ErrorRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    primaryContainer = SendoraLightSurfaceVariant,
    onPrimaryContainer = ElectricBlueDark,
    secondary = ElectricBlueDark,
    onSecondary = Color.White,
    tertiary = CyanAccentDark,
    background = SendoraLightBg,
    onBackground = TextPrimaryLight,
    surface = SendoraLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = SendoraLightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = SendoraLightBorder,
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun SendoraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PairingSession
import com.example.data.repository.SettingsRepository
import com.example.network.discovery.DeviceDiscoveryManager
import com.example.network.transfer.TransferManager
import com.example.qr.QrGenerator
import com.example.qr.QrScannerView
import com.example.ui.components.RadarPulseAnimation
import com.example.ui.components.SendoraActionButton
import com.example.ui.components.SendoraCard
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SendoraDarkBorder
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

@Composable
fun ReceiveScreen(
    settingsRepository: SettingsRepository,
    discoveryManager: DeviceDiscoveryManager,
    transferManager: TransferManager,
    onBack: () -> Unit,
    onTransferAccepted: () -> Unit
) {
    val settings by settingsRepository.settings.collectAsStateWithLifecycle()
    val transferState by transferManager.transferState.collectAsStateWithLifecycle()

    var showQrDialog by remember { mutableStateOf(false) }
    var showCameraScanner by remember { mutableStateOf(false) }
    var showCodeDialog by remember { mutableStateOf(false) }
    var manualCodeInput by remember { mutableStateOf("") }

    val localIp = remember { discoveryManager.getLocalIpAddress() ?: "127.0.0.1" }
    val pairingCode = remember { (100000..999999).random().toString() }

    val pairingSession = remember(localIp, settings.deviceName) {
        PairingSession(
            sessionId = UUID.randomUUID().toString(),
            deviceName = settings.deviceName,
            ipAddress = localIp,
            port = 8888,
            authToken = pairingCode
        )
    }

    val qrPayload = remember(pairingSession) {
        JSONObject().apply {
            put("app", "SENDORA")
            put("sid", pairingSession.sessionId)
            put("name", pairingSession.deviceName)
            put("ip", pairingSession.ipAddress)
            put("port", pairingSession.port)
            put("token", pairingSession.authToken)
        }.toString()
    }

    val qrBitmap = remember(qrPayload) {
        QrGenerator.generateQrBitmap(qrPayload)
    }

    // Start discovery and TCP server when screen is open
    LaunchedEffect(Unit) {
        discoveryManager.startDiscovery(settings.deviceName)
        transferManager.startServer(settings.deviceName)
    }

    // Listen for incoming transfer proposal
    LaunchedEffect(transferState.incomingProposal) {
        if (transferState.incomingProposal != null) {
            showQrDialog = false
            showCameraScanner = false
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Text(
                    text = "Receive Files",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    ) { innerPadding ->
        if (showCameraScanner) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                QrScannerView(
                    onQrScanned = { payloadStr ->
                        try {
                            val json = JSONObject(payloadStr)
                            if (json.optString("app") == "SENDORA") {
                                val targetIp = json.getString("ip")
                                val targetPort = json.getInt("port")
                                showCameraScanner = false
                            }
                        } catch (e: Exception) {}
                    }
                )
                IconButton(
                    onClick = { showCameraScanner = false },
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Scanner",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Device name status
                item {
                    SendoraCard(
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "receive_status_card"
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadarPulseAnimation(sizeDp = 180.dp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = settings.deviceName,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(CyanAccent)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Ready to receive on local network ($localIp)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyanAccent
                                )
                            }
                        }
                    }
                }

                // Incoming Proposal Card if active
                transferState.incomingProposal?.let { proposal ->
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .border(2.dp, CyanAccent, RoundedCornerShape(20.dp))
                                .testTag("incoming_transfer_proposal_card"),
                            colors = CardDefaults.cardColors(
                                containerColor = ElectricBlue.copy(alpha = 0.15f)
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "INCOMING FILE TRANSFER",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.2.sp
                                    ),
                                    color = CyanAccent
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "${proposal.senderName} wants to send files",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${proposal.files.size} file(s) • Total size: ${formatSize(proposal.totalSize)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            transferManager.rejectIncomingTransfer(proposal)
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                            contentColor = MaterialTheme.colorScheme.error
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Close, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("REJECT")
                                    }

                                    Button(
                                        onClick = {
                                            transferManager.acceptIncomingTransfer(proposal)
                                            onTransferAccepted()
                                        },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = ElectricBlue,
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("ACCEPT")
                                    }
                                }
                            }
                        }
                    }
                }

                // Connection Action Buttons
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SendoraActionButton(
                            text = "Create Connection (Show QR)",
                            onClick = { showQrDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            icon = Icons.Default.QrCode,
                            containerColor = ElectricBlue,
                            testTag = "create_connection_qr_button"
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SendoraActionButton(
                                text = "Scan QR Code",
                                onClick = { showCameraScanner = true },
                                modifier = Modifier.weight(1f),
                                icon = Icons.Default.QrCodeScanner,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = CyanAccent,
                                testTag = "scan_qr_code_button"
                            )

                            SendoraActionButton(
                                text = "Enter Code",
                                onClick = { showCodeDialog = true },
                                modifier = Modifier.weight(1f),
                                icon = Icons.Default.Key,
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurface,
                                testTag = "enter_code_button"
                            )
                        }
                    }
                }
            }
        }

        // Show QR Code Dialog
        if (showQrDialog) {
            AlertDialog(
                onDismissRequest = { showQrDialog = false },
                title = {
                    Text(
                        text = "Receive QR Code",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                text = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        qrBitmap?.let { bmp ->
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Sendora QR Code",
                                modifier = Modifier
                                    .size(220.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.White)
                                    .padding(8.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Pairing Code: $pairingCode",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.sp
                            ),
                            color = CyanAccent
                        )
                        Text(
                            text = "Scan this code on sender device to pair directly",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showQrDialog = false }) {
                        Text("Close", color = ElectricBlue)
                    }
                }
            )
        }

        // Enter Code Dialog
        if (showCodeDialog) {
            AlertDialog(
                onDismissRequest = { showCodeDialog = false },
                title = { Text("Manual Pairing Code") },
                text = {
                    Column {
                        Text(
                            text = "Enter the 6-digit pairing code shown on sender phone:",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = manualCodeInput,
                            onValueChange = { if (it.length <= 6) manualCodeInput = it },
                            label = { Text("6-Digit Code") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showCodeDialog = false
                        },
                        enabled = manualCodeInput.length == 6
                    ) {
                        Text("Pair")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCodeDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

private fun formatSize(bytes: Long): String {
    return when {
        bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.1f GB", bytes / (1024f * 1024f * 1024f))
        bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024f * 1024f))
        bytes >= 1024 -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
        else -> "$bytes B"
    }
}

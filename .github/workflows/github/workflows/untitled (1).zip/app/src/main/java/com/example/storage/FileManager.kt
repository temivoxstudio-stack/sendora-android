package com.example.storage

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.example.data.model.FileCategory
import com.example.data.model.SelectedFile
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

class FileManager(private val context: Context) {

    fun getFileInfoFromUri(uri: Uri): SelectedFile? {
        val contentResolver = context.contentResolver
        var fileName = "unknown_file"
        var fileSize = 0L
        var mimeType = contentResolver.getType(uri) ?: "application/octet-stream"

        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) {
                    fileName = cursor.getString(nameIndex) ?: fileName
                }
                if (sizeIndex != -1) {
                    fileSize = cursor.getLong(sizeIndex)
                }
            }
        }

        if (mimeType == "application/octet-stream" && fileName.contains(".")) {
            val extension = fileName.substringAfterLast('.', "")
            val inferredMime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.lowercase())
            if (!inferredMime.isNullOrBlank()) {
                mimeType = inferredMime
            }
        }

        val category = determineCategory(fileName, mimeType)
        return SelectedFile(
            id = uri.toString(),
            uri = uri,
            name = fileName,
            size = fileSize,
            mimeType = mimeType,
            category = category
        )
    }

    fun determineCategory(fileName: String, mimeType: String): FileCategory {
        val lowerName = fileName.lowercase()
        return when {
            mimeType.startsWith("image/") || lowerName.endsWith(".jpg") || lowerName.endsWith(".png") || lowerName.endsWith(".jpeg") || lowerName.endsWith(".webp") || lowerName.endsWith(".gif") -> FileCategory.PHOTOS
            mimeType.startsWith("video/") || lowerName.endsWith(".mp4") || lowerName.endsWith(".mkv") || lowerName.endsWith(".avi") || lowerName.endsWith(".mov") -> FileCategory.VIDEOS
            mimeType.startsWith("audio/") || lowerName.endsWith(".mp3") || lowerName.endsWith(".wav") || lowerName.endsWith(".aac") || lowerName.endsWith(".flac") || lowerName.endsWith(".m4a") -> FileCategory.MUSIC
            mimeType.contains("pdf") || mimeType.contains("document") || mimeType.contains("text") || lowerName.endsWith(".pdf") || lowerName.endsWith(".doc") || lowerName.endsWith(".docx") || lowerName.endsWith(".txt") || lowerName.endsWith(".epub") -> FileCategory.DOCUMENTS
            mimeType == "application/vnd.android.package-archive" || lowerName.endsWith(".apk") -> FileCategory.APKS
            mimeType.contains("zip") || mimeType.contains("tar") || mimeType.contains("rar") || lowerName.endsWith(".zip") || lowerName.endsWith(".rar") || lowerName.endsWith(".7z") -> FileCategory.ZIPS
            else -> FileCategory.OTHER
        }
    }

    fun openInputStream(uri: Uri): InputStream? {
        return context.contentResolver.openInputStream(uri)
    }

    fun createDownloadOutputStream(fileName: String, mimeType: String): OutputStreamResult {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/Sendora")
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                val outputStream = context.contentResolver.openOutputStream(uri)
                if (outputStream != null) {
                    return OutputStreamResult(outputStream, uri, "Downloads/Sendora/$fileName")
                }
            }
        }

        val sendoraDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Sendora")
        if (!sendoraDir.exists()) {
            sendoraDir.mkdirs()
        }
        val file = File(sendoraDir, fileName)
        val fileOutputStream = FileOutputStream(file)
        val fileUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        return OutputStreamResult(fileOutputStream, fileUri, file.absolutePath)
    }

    fun openFileIntent(uri: Uri, mimeType: String): Intent {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return intent
    }

    data class OutputStreamResult(
        val outputStream: OutputStream,
        val fileUri: Uri,
        val savedPath: String
    )
}

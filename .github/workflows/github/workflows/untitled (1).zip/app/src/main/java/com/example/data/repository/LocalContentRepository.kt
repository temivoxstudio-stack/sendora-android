package com.example.data.repository

import android.content.ContentResolver
import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.example.data.model.FileCategory
import com.example.data.model.SelectedFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class AppContentItem(
    val packageName: String,
    val name: String,
    val size: Long,
    val apkPath: String,
    val uri: Uri,
    val icon: Drawable?,
    val isHot: Boolean = false
)

data class LocalMediaItem(
    val id: String,
    val uri: Uri,
    val name: String,
    val size: Long,
    val mimeType: String,
    val category: FileCategory,
    val durationMs: Long = 0L,
    val artist: String = ""
)

class LocalContentRepository(private val context: Context) {

    suspend fun getInstalledApps(): List<AppContentItem> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val packages = try {
            pm.getInstalledPackages(0)
        } catch (e: Exception) {
            emptyList()
        }

        val list = mutableListOf<AppContentItem>()
        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val launchIntent = pm.getLaunchIntentForPackage(pkg.packageName)

            // Include user-installed apps and system apps that have launcher intents
            if (!isSystem || launchIntent != null) {
                val appName = try {
                    appInfo.loadLabel(pm).toString()
                } catch (e: Exception) {
                    pkg.packageName
                }
                val apkFile = File(appInfo.sourceDir)
                if (apkFile.exists()) {
                    val icon = try {
                        appInfo.loadIcon(pm)
                    } catch (e: Exception) {
                        null
                    }
                    list.add(
                        AppContentItem(
                            packageName = pkg.packageName,
                            name = appName,
                            size = apkFile.length(),
                            apkPath = appInfo.sourceDir,
                            uri = Uri.fromFile(apkFile),
                            icon = icon,
                            isHot = false
                        )
                    )
                }
            }
        }

        val sorted = list.sortedBy { it.name.lowercase(Locale.ROOT) }
        // Mark top 2 popular names if present as "Hot" for top preview row
        val hotPackages = setOf("com.whatsapp", "com.instagram.android", "com.zhiliaoapp.musically", "com.facebook.katana")
        sorted.map { app ->
            if (hotPackages.contains(app.packageName)) app.copy(isHot = true) else app
        }
    }

    suspend fun getLocalPhotos(): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<LocalMediaItem>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.MIME_TYPE
        )

        try {
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null, null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "Photo_$id.jpg"
                    val size = cursor.getLong(sizeCol)
                    val mime = cursor.getString(mimeCol) ?: "image/jpeg"
                    val contentUri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())

                    list.add(
                        LocalMediaItem(
                            id = "photo_$id",
                            uri = contentUri,
                            name = name,
                            size = size,
                            mimeType = mime,
                            category = FileCategory.PHOTOS
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        list
    }

    suspend fun getLocalVideos(): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<LocalMediaItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.MIME_TYPE
        )

        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null, null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "Video_$id.mp4"
                    val size = cursor.getLong(sizeCol)
                    val duration = cursor.getLong(durCol)
                    val mime = cursor.getString(mimeCol) ?: "video/mp4"
                    val contentUri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString())

                    list.add(
                        LocalMediaItem(
                            id = "video_$id",
                            uri = contentUri,
                            name = name,
                            size = size,
                            mimeType = mime,
                            category = FileCategory.VIDEOS,
                            durationMs = duration
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        list
    }

    suspend fun getLocalMusic(): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<LocalMediaItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DURATION
        )

        try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null, null,
                "${MediaStore.Audio.Media.TITLE} ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Track_$id"
                    val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                    val size = cursor.getLong(sizeCol)
                    val mime = cursor.getString(mimeCol) ?: "audio/mpeg"
                    val duration = cursor.getLong(durCol)
                    val contentUri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString())

                    val ext = if (mime.contains("mpeg") || mime.contains("mp3")) ".mp3" else ""
                    val filename = if (title.endsWith(".mp3") || title.endsWith(".m4a")) title else "$title$ext"

                    list.add(
                        LocalMediaItem(
                            id = "music_$id",
                            uri = contentUri,
                            name = filename,
                            size = size,
                            mimeType = mime,
                            category = FileCategory.MUSIC,
                            durationMs = duration,
                            artist = artist
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        list
    }

    suspend fun getLocalFiles(): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        val list = mutableListOf<LocalMediaItem>()
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE
        )

        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_NONE}"

        try {
            context.contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                projection,
                selection, null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "File_$id"
                    val size = cursor.getLong(sizeCol)
                    val mime = cursor.getString(mimeCol) ?: "application/octet-stream"
                    val contentUri = Uri.withAppendedPath(MediaStore.Files.getContentUri("external"), id.toString())

                    val category = determineCategory(name, mime)

                    list.add(
                        LocalMediaItem(
                            id = "file_$id",
                            uri = contentUri,
                            name = name,
                            size = size,
                            mimeType = mime,
                            category = category
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        list
    }

    private fun determineCategory(fileName: String, mimeType: String): FileCategory {
        val lower = fileName.lowercase(Locale.ROOT)
        return when {
            mimeType.startsWith("image/") || lower.endsWith(".jpg") || lower.endsWith(".png") || lower.endsWith(".jpeg") -> FileCategory.PHOTOS
            mimeType.startsWith("video/") || lower.endsWith(".mp4") || lower.endsWith(".mkv") -> FileCategory.VIDEOS
            mimeType.startsWith("audio/") || lower.endsWith(".mp3") || lower.endsWith(".wav") || lower.endsWith(".m4a") -> FileCategory.MUSIC
            mimeType.contains("pdf") || mimeType.contains("document") || mimeType.contains("text") || lower.endsWith(".pdf") || lower.endsWith(".doc") || lower.endsWith(".docx") || lower.endsWith(".txt") -> FileCategory.DOCUMENTS
            mimeType == "application/vnd.android.package-archive" || lower.endsWith(".apk") -> FileCategory.APKS
            mimeType.contains("zip") || lower.endsWith(".zip") || lower.endsWith(".rar") -> FileCategory.ZIPS
            else -> FileCategory.OTHER
        }
    }
}
